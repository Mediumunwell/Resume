#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <errno.h>
#include "nrutil.h"
#include "nr.h"

void printMatrix(double** m, int Rows, int Columns){
    int row, column;
    for (row=1; row<Rows+1; row++){
      printf("\n");
      for(column=1; column<Columns+1; column++){
    
         printf("%8s %12.6lg"," ", m[row][column]);
      }
    }
    printf("\n");    
}

double **readmatrix(size_t *rows, size_t *cols, const char *filename)
{
    if(rows == NULL || cols == NULL || filename == NULL)
        return NULL;

    *rows = 0;
    *cols = 0;

    FILE *fp = fopen(filename, "r");

    if(fp == NULL)
    {
        fprintf(stderr, "could not open %s\n", filename);
        return NULL;
    }

    double **mat = NULL, **tmp;

    char line[1024];

    while(fgets(line, sizeof line, fp))
    {
        if(*cols == 0)
        {
            // determine the size of the columns based on
            // the first row
            char *scan = line;
            double dummy;
            int offset = 0;
            while(sscanf(scan, "%lg%n", &dummy, &offset) == 1)
            {
                scan += offset;
                (*cols)++;
            }
        }

        tmp = realloc(mat, (*rows + 1) * sizeof *mat);

        if(tmp == NULL)
        {
            fclose(fp);
            return mat; // return all you've parsed so far
        }

        mat = tmp;

        mat[*rows] = calloc(*cols, sizeof *mat[*rows]);

        if(mat[*rows] == NULL)
        {
            fclose(fp);
            if(*rows == 0) // failed in the first row, free everything
            {
                fclose(fp);
                free(mat);
                return NULL;
            }

            return mat; // return all you've parsed so far
        }

        int offset = 0;
        char *scan = line;
        for(size_t j = 0; j < *cols; ++j)
        {
            if(sscanf(scan, "%lg%n", mat[*rows] + j, &offset) == 1)
                scan += offset;
            else
                mat[*rows][j] = 0; // could not read, set cell to 0
        }

        // incrementing rows
        (*rows)++;
    }

    fclose(fp);

    return mat;
}

int main(void)
{
  double Ixx, Iyy, Izz, Ixy, Iyz, Ixz, Lx, Ly, Lz, P, r_x, r_y, r_z, v_x, v_y, v_z;
  int m=3, n=3;

  size_t cols, rows;
  double **r = readmatrix(&rows, &cols, "ps2.dat");

    if(r == NULL)
    {
        fprintf(stderr, "could not read matrix\n");
        return 1;
    }
    printf("\ndata row count: %ld", rows);
    for(size_t i = 0; i < rows; ++i){
        for(size_t j = 0; j < cols; ++j){
          //printf("%-3g ", matrix[i][j]);
          //puts("");
          if (j==2){
            r_x=(r[i][0]);
            r_y=(r[i][1]);
            r_z=(r[i][2]);
            Ixx+=r_x*r_x+r_z*r_z;
            Iyy+=r_x*r_x+r_z*r_z;
            Izz+=r_x*r_x+r_y*r_y;
            Ixy+=-r_x*r_y;
            Iyz+=-r_y*r_z;
            Ixz+=-r_x*r_z;
          }
          if (j==5){
            v_x=(r[i][3]);
            v_y=(r[i][4]);
            v_z=(r[i][5]);
            Lx+=r_y*v_z-r_z*v_y;
            Ly+=r_z*v_x-r_x*v_z;
            Lz+=r_x*v_y-r_y*v_x;
          }
        }
    }
    double I[3][3]={{Ixx,Ixy,Ixz},{Ixy,Iyy,Iyz},{Ixz,Iyz,Izz}};
    double L[3]={Lx,Ly,Lz};
    double L2[3]={Lx,Ly,Lz};

  double **II, **LL, **ww;
  II=dconvert_matrix(&I[0][0], 1,3,1,3);
  LL=dconvert_matrix(&L2[0], 1,3,1,1);
 
  printf("\n\nConverted I =\n"),
  printMatrix(II,3,3);
  printf("\n\nConverted L =\n"),
  printMatrix(LL,1,3);

  // Gauss Jordan
  dgaussj(II,3,LL,1);
  printf( "\n ---Gauss Jordan---\n\n" );
  printf("Gauss A-inverse =\n");
  printMatrix(II,3,3);

  // check inverse
  printf("\na times a-inverse:\n\n");
  double u[3][3];
  for (int k=0;k<n;k++) {
    for (int l=0;l<n;l++){
      u[k][l]=0.0;   
      for (int j=0;j<n;j++){
        u[k][l] += (I[k][j]*II[j+1][l+1]);
      }
    }
    for (int l=0;l<n;l++) 
      printf("\t %12.6g   ",u[k][l]);
      printf("\n");
  }

    /* check vector solutions */
/*    printf("\nCheck the following for equality:\n");
    printf("%21s %14s\n","original","matrix*sol'n\n");
    double t[3][3]; /* t is an n*m matrix defined to test the solution. */
/*    for (int l=0;l<m;l++) {
      ("vector %2d: \n",l);
      for (int k=0;k<n;k++) {
        t[k][l]=0.0;
        for (int j=0;j<n;j++){
          t[k][l] += (I[k][j]*L2[j+1]);
          printf("%8s %12.6g %12.6g\n"," ", L[k],t[k][l]);
        }
      }
    }
*/

// Print Solution
    printf( " \n\n " );
    printf("Gauss-Jordan Solution:\n\n \t ω = ");
    printf("< %lg , %lg , %lg > \n", LL[1][1], LL[1][2], LL[1][3]);
    printf( " \n\n " );
    P=2*M_PI/sqrt(LL[1][1]*LL[1][1]+LL[1][2]*LL[1][2]+LL[1][3]*LL[1][3]);
    printf("Period Solution: P = 2π/sqrt(ω_x^2 + ω_y^2 + ω_z^2) = %.4lg sec = %.2lg hours", P, P/3600);
    //printMatrix(LL,1,3);

    

// freeing memory
  for(size_t i = 0; i < rows; ++i){
    free(r[i]);
  }
  free(r);
  printf("\n\n");
  return 0;
}

/*  Notes on gaussj function
    * aj=ai=a before gaussj is called, ai = inverse(a) after the function call. (av=a, it is used to run SVD)
    * u = ai*a, we define this to test the program, 
    *     if correct u should be the unit matrix.
    * b = matrix of dimension n*m where m is the number of r.h.s. vectors for which 
    *     you want to solve A.x = b.
    * x = b before gaussj is called, x is the solution vector after gaussj is called. 
*/


/* fill m[ROWS][COLS] with values read from fp.
 * returns 1 on success, 0 otherwise.
 */
/*
int getmatrix (double (*m)[COLS], FILE *fp)
{
  for (int row = 0; row < ROWS; row++) {
    for (int col = 0; col < COLS; col++) {
      if (fscanf (fp, "%lg", &m[row][col]) != 1) {
        fprintf (stderr, "error reading m[%d][%d]\n", row, col);
        return 0;
      }
    }
  }
  return 1;
}

void prnmatrix (double (*m)[COLS])
{
  for (int row = 0; row < ROWS; row++) {
    for (int col = 0; col < COLS; col++) {
      printf (col ? " %4lg" : "%4lg", m[row][col]);
    }
    putchar ('\n');
  }
}
*/