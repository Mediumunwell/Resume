#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* constants for number of columns, buffer chars, and initial allocation */
enum { NCOL = 4, MAXC = 32, MAXN = 1908 };

void *xcalloc (size_t nmemb, size_t sz);
void *xrealloc (void *ptr, size_t psz, size_t *nelem);
FILE *xfopen (const char *fn, const char *mode);

int main (int argc, char **argv) {

    char buf[MAXC] = {0};
    char *fmt = "%d;%d";
    int (*arr)[NCOL] = NULL;
    size_t i, idx = 0, maxn = MAXN;
    FILE *fp = argc > 1 ? xfopen (argv[1], "r") : stdin;

    /* alloc mem for array of MAXN elements */
    arr = xcalloc (maxn, sizeof *arr);

    while (fgets (buf, MAXC, fp)) {     /* read each line of input */
        int a, b;                       /* parse line for values */
        if (sscanf (buf, fmt, &a, &b) != NCOL) continue;
        arr[idx][0] = a, arr[idx][1] = b;
        if (++idx == maxn)              /* realloc as needed  */
            arr = xrealloc (arr, sizeof *arr, &maxn);
    }
    if (fp != stdin) fclose (fp);       /* close if not stdin */

    for (i = 0; i < idx; i++)
        printf (" array[%3zu][0] : %4d    [1] : %d\n", i, arr[i][0], arr[i][1]);

    free (arr);     /* free allocated memory */

    return 0;
}

/** xcalloc allocates memory using calloc and validates the return. */
void *xcalloc (size_t nmemb, size_t sz)
{   register void *memptr = calloc (nmemb, sz);
    if (!memptr) {
        fprintf (stderr, "xcalloc() error: virtual memory exhausted.\n");
        exit (EXIT_FAILURE);
    }
    return memptr;
}

/** realloc 'ptr' to array of elements of 'psz' to 'nelem + MAXN' elements */
void *xrealloc (void *ptr, size_t psz, size_t *nelem)
{   void *tmp = realloc ((char *)ptr, (*nelem + MAXN) * psz);
    if (!tmp) {
        fprintf (stderr, "realloc() error: virtual memory exhausted.\n");
        exit (EXIT_FAILURE);                
    }
    memset (tmp + *nelem * psz, 0, MAXN * psz);  /* zero new memory */
    *nelem += MAXN;
    return tmp;
}

/** fopen with error checking - short version */
FILE *xfopen (const char *fn, const char *mode)
{   FILE *fp = fopen (fn, mode);
    if (!fp) {
        fprintf (stderr, "xfopen() error: file open failed '%s'.\n", fn);
        // return NULL;      /* choose appropriate action */
        exit (EXIT_FAILURE);
    }
    return fp;
}