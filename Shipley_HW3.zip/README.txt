The code compiles, runs all the homework files, and plots the asteroid using the Makefile

   mal_mat.c is a method for reading data into a matrix with options to use malloc, realloc, and xcalloc
      I just haven't figured out how to use this method, yet
   dgaussj.c is my version of gaussj that uses double precision instead of single precision

Type make in the linux command line to:
   compile problem1.c and problem2.c with cc nrutil.c dgaussj.c -lm -g 
   run the resulting executable files named 1 and 2
   Plot asteroid.plt

Type make clean to remove all created files after running make