/*
include files/functions
*/
#ifndef ES_HW3
#define ES_HW3

void printMatrix(double** m, int Rows, int Columns);
double **readmatrix(size_t *rows, size_t *cols, const char *filename);

#endif