#include <stdio.h>
#include <math.h>

int main(){
    printf("\n Golden Mean Power 'n' Recursion Relation\n");
    float phi[21], phi_d[20];
    phi[0]=1;
    phi_d[0]=1;
    phi[1]=(sqrt(5)-1)/2;
    phi_d[1]=(sqrt(5)-1)/2;
    printf("============================================\n");
    printf("|  n  | φn+1 = φ^(n−1)−φ^n | φn = φφ^(n-1) |\n");
    printf("--------------------------------------------\n");
    for (int i = 1; i < 21; i++) {
      phi[i+1] = phi[i-1]-phi[i];
      phi_d[i] = phi_d[1]*phi_d[i-1];
    }
    for (int i = 1; i < 5; i++) {
      printf("|  %d  |        %.3g       |     %.3g     |\n", i, phi[i], phi_d[i]);
      printf("--------------------------------------------\n");
    }
    for (int i = 5; i < 10; i++) {
      printf("|  %d  |        %.3g      |     %.3g    |\n", i, phi[i], phi_d[i]);
      printf("--------------------------------------------\n");
    }
    for (int i = 10; i < 15; i++) {
      if (i==12){
        printf("|  %d |        %.3g      |     %.3g   |\n", i, phi[i], phi_d[i]);
      }
      else{
        printf("|  %d |       %.3g      |     %.3g   |\n", i, phi[i], phi_d[i]);
      }
      printf("--------------------------------------------\n");
    }
    for (int i = 15; i < 21; i++) {
      if (i==17){
        printf("|  %d |      %.3g      |     %.3g   |\n", i, phi[i], phi_d[i]);
      }
      else{
        if (i==20){
          printf("|  %d |      %.3g     |    %.3g   |\n", i, phi[i], phi_d[i]);
        }
        else{
          printf("|  %d |      %.3g      |    %.3g   |\n", i, phi[i], phi_d[i]);
        }
      }
      printf("--------------------------------------------\n");
    }
    printf("\n\n");
    return 0;
}