#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "nrutil.h"
#include "nr.h"

FILE *fpt;

int main(){
  int N=10000;
  long int seed=5123456789;
  fpt = fopen("Rayleigh_Distribution.csv", "w+");
  fprintf(fpt,"R\n");
  for (int i=0; i<N; ++i){
    float y=sqrt(-2*log(1-ran1(&seed)));
    fprintf(fpt,"%f\n", y);
  }
  fclose(fpt);
}