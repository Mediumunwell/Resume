The code compiles, runs all the homework files, and plots the Rayleigh distribution/function and Mass values using the Makefile

Type make in the linux command line to:
   compile problem1.c and problem2.c with cc nrutil.c ran1.c -lm -g 
   run the resulting executable files named 1 and 2
   Plot the Rayleigh Distributed Deviate histogram with Rayleigh continuous probability function
   Plot the mass of the nonuniformly shaped and nonuniformly dense object with errorbars

Type make clean to remove all created files after running make



files:
HW4.pdf     writeup of solutions with figures

Makefile    compiles and plots the following

problem1.c  solution to question (1)

problem2.c  solution to question (2)

nrutil.c    Numerical Recipes in C

ran1.C      random number generator

*.plt       gnuplot files to plot graphs

include
 >ES_HW4.h  header for makefile

nr.H        header for Numerical Recipes

make:
   *.csv    data files for plots
   *.png    plots
