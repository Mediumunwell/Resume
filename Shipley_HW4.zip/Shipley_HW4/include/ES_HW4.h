/*
include files/functions
*/
#ifndef ES_HW4
#define ES_HW4

void ran1(long*);

#endif