#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "nrutil.h"
#include "nr.h"

FILE *fpt2_M;

int main(){

float w, x, y, z, dw, dx, dy, dz, sw, swx, swy, swz, varw, varx, vary, varz;
long idum=554455;

float vol=6.0*6.0*6.0; //Volume of the sampled region.

int n[7]; 
fpt2_M = fopen("Object_Mass.csv", "w+");
fprintf(fpt2_M,"Iterations\t        M\t\t	     sigma_M\n");

for(int i = 1; i <= 7; i++){
  n[i] = pow(10,i);  //Setting to the number of sample points desired.
  sw=swx=swy=swz=0.0; //Zero the various sums to be accumulated.
  varw=varx=vary=varz=0.0;
  for(int j=1;j<=n[i];j++) {
    float x=-3.0 + 6.0*ran1(&idum); //Pick a point randomly in the sampled region.
    float y=-3.0 + 6.0*ran1(&idum);
    float z=-3.0 + 6.0*ran1(&idum);
    if (sqrt(z*z+x*x+y*y) < 3.0 && x >= 0.0 && y >= -1.0) { //Is it in the object?
      float den=1+x*x+3*(y+z)*(y+z); //Set density.
      sw += den;
      swx += x*den;
      swy += y*den;
      swz += z*den;
      varw += SQR(den);
      varx += SQR(x*den);
      vary += SQR(y*den);
      varz += SQR(z*den);
    }
  }
  w=vol*sw/n[i]; //The values of the integrals (7.6.5),
  x=vol*swx/n[i];
  y=vol*swy/n[i];
  z=vol*swz/n[i];
  dw=vol*sqrt((varw/n[i]-SQR(sw/n[i]))/n[i]); //and their corresponding error estimates.
  dx=vol*sqrt((varx/n[i]-SQR(swx/n[i]))/n[i]);
  dy=vol*sqrt((vary/n[i]-SQR(swy/n[i]))/n[i]);
  dz=vol*sqrt((varz/n[i]-SQR(swz/n[i]))/n[i]);
  fprintf(fpt2_M,"%d\t\t\t,    %f\t\t,   %f\n", n[i],  w, dw);
  }
fclose(fpt2_M);
}