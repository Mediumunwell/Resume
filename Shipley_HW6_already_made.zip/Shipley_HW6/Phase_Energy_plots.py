import numpy as np
import matplotlib
from matplotlib import animation
from matplotlib.colors import BASE_COLORS as palette
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d.axes3d as axes3d
import pandas as pd

#########################################################################################################
# Orbit 1 No Softening
#########################################################################################################

df=pd.read_csv('data_rk4.csv')
df.columns = ['t', 'x', 'y', 'z', 'vx', 'vy', 'vz', 'x2', 'y2', 'z2', 'vx2', 'vy2', 'vz2']
t = df['t']
x = df['x']
y = df['y']
z = df['z']
x2 = df['x2']
y2 = df['y2']
z2 = df['z2']
vx = df['vx']
vy = df['vy']
vz = df['vz']
vx2 = df['vx2']
vy2 = df['vy2']
vz2 = df['vz2']

KE_list = []
U_list = []
E_tot_list = []
t_list = []

fig = plt.figure(1,figsize=(10,8))
ax = fig.add_subplot(1,1,1)
for k in range(241):
    r=((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    vr=((x[k]-x2[k])*(vx[k]-vx2[k])+(y[k]-y2[k])*(vy[k]-vy2[k])+(z[k]-z2[k])*(vz[k]-vz2[k]))/((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    ax.scatter(vr,r)
    

ax.set_title(r'$RK4\ Orbit\ 1\ No\ Softening\ Phase\ Plot$')
ax.set_ylabel(r'$Distance\ (\mathcal{r}$)')
ax.set_xlabel(r'$Velocity\ (\mathcal{v}_r$)')
fig.savefig("Orbit1_RK4_Phase_Plot.png")

fig2=plt.figure(2,figsize=(10,8))
ax2 = fig2.add_subplot(1,1,1)
for i in range(241):
    KE=(vx[i]**2+vy[i]**2+vz[i]**2)/2+(vx2[i]**2+vy2[i]**2+vz2[i]**2)/2
    U=-1/((x[i]-x2[i])**2+(y[i]-y2[i])**2+(z[i]-z2[i])**2)**(1/2)
    E_tot=KE+U
    KE_list += [KE]
    U_list += [U]
    E_tot_list += [E_tot]
    t_list += [t[i]]
    
KE_arr = np.vstack(KE_list)
U_arr = np.vstack(U_list)
E_tot_arr = np.vstack(E_tot_list)
t_arr = np.vstack(t_list)

ax2.plot(t_arr,E_tot_arr,label='Total Energy')
ax2.plot(t_arr,KE_arr,label='Kinetic Energy')
ax2.plot(t_arr,U_arr,label='Potential Energy')

ax2.set_title(r'$Energy\ vs\ Time\ For\ Orbit\ 1\ Leapfrog\ No\ Softening$')
ax2.set_ylabel(r'$Energy\  (E)$')
ax2.set_xlabel(r'$Time\ (\mathcal{t}$)')
ax2.legend(prop={'size': 6});

fig2.savefig("Orbit1_RK4_Energy_Plot.png")


#########################################################################################################

df=pd.read_csv('data_leap.csv')
df.columns = ['t', 'x', 'y', 'z', 'vx', 'vy', 'vz', 'x2', 'y2', 'z2', 'vx2', 'vy2', 'vz2']
t = df['t']
x = df['x']
y = df['y']
z = df['z']
x2 = df['x2']
y2 = df['y2']
z2 = df['z2']
vx = df['vx']
vy = df['vy']
vz = df['vz']
vx2 = df['vx2']
vy2 = df['vy2']
vz2 = df['vz2']

KE_list = []
U_list = []
E_tot_list = []
t_list = []

fig3 = plt.figure(3,figsize=(10,8))
ax3 = fig3.add_subplot(1,1,1)
for k in range(241):
    r=((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    vr=((x[k]-x2[k])*(vx[k]-vx2[k])+(y[k]-y2[k])*(vy[k]-vy2[k])+(z[k]-z2[k])*(vz[k]-vz2[k]))/((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    ax3.scatter(vr,r)
    

ax3.set_title(r'$Leapfrog\ Orbit\ 1\ No\ Softening\ Phase\ Plot$')
ax3.set_ylabel(r'$Distance\ (\mathcal{r}$)')
ax3.set_xlabel(r'$Velocity\ (\mathcal{v}_r$)')
fig3.savefig("Orbit1_Leapfrog_Phase_Plot.png")

fig4=plt.figure(4,figsize=(10,8))
ax4 = fig4.add_subplot(1,1,1)
for i in range(241):
    KE=(vx[i]**2+vy[i]**2+vz[i]**2)/2+(vx2[i]**2+vy2[i]**2+vz2[i]**2)/2
    U=-1/((x[i]-x2[i])**2+(y[i]-y2[i])**2+(z[i]-z2[i])**2)**(1/2)
    E_tot=KE+U
    KE_list += [KE]
    U_list += [U]
    E_tot_list += [E_tot]
    t_list += [t[i]]
    
KE_arr = np.vstack(KE_list)
U_arr = np.vstack(U_list)
E_tot_arr = np.vstack(E_tot_list)
t_arr = np.vstack(t_list)

ax4.plot(t_arr,E_tot_arr,label='Total Energy')
ax4.plot(t_arr,KE_arr,label='Kinetic Energy')
ax4.plot(t_arr,U_arr,label='Potential Energy')

ax4.set_title(r'$Energy\ vs\ Time\ For\ Orbit\ 1\ Leapfrog\ No\ Softening$')
ax4.set_ylabel(r'$Energy\  (E)$')
ax4.set_xlabel(r'$Time\ (\mathcal{t}$)')
ax4.legend(prop={'size': 6});

fig4.savefig("Orbit1_Leapfrog_Energy_Plot.png")

print("Completed Orbit 1 Leapfrog/RK4 Phase/Energy Graphs With No Softening")

#########################################################################################################
# Orbit 1 Softened
#########################################################################################################

df=pd.read_csv('data_rk4_soft.csv')
df.columns = ['t', 'x', 'y', 'z', 'vx', 'vy', 'vz', 'x2', 'y2', 'z2', 'vx2', 'vy2', 'vz2']
t = df['t']
x = df['x']
y = df['y']
z = df['z']
x2 = df['x2']
y2 = df['y2']
z2 = df['z2']
vx = df['vx']
vy = df['vy']
vz = df['vz']
vx2 = df['vx2']
vy2 = df['vy2']
vz2 = df['vz2']

KE_list = []
U_list = []
E_tot_list = []
t_list = []

fig5 = plt.figure(5,figsize=(10,8))
ax5 = fig5.add_subplot(1,1,1)
for k in range(241):
    r=((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    vr=((x[k]-x2[k])*(vx[k]-vx2[k])+(y[k]-y2[k])*(vy[k]-vy2[k])+(z[k]-z2[k])*(vz[k]-vz2[k]))/((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    ax5.scatter(vr,r)
    

ax5.set_title(r'$RK4\ Orbit\ 1\ Softened\ Phase\ Plot$')
ax5.set_ylabel(r'$Distance\ (\mathcal{r}$)')
ax5.set_xlabel(r'$Velocity\ (\mathcal{v}_r$)')
fig5.savefig("Orbit1_RK4_Soft_Phase_Plot.png")

fig6=plt.figure(6,figsize=(10,8))
ax6 = fig6.add_subplot(1,1,1)
for i in range(241):
    KE=(vx[i]**2+vy[i]**2+vz[i]**2)/2+(vx2[i]**2+vy2[i]**2+vz2[i]**2)/2
    U=-1/((x[i]-x2[i])**2+(y[i]-y2[i])**2+(z[i]-z2[i])**2)**(1/2)
    E_tot=KE+U
    KE_list += [KE]
    U_list += [U]
    E_tot_list += [E_tot]
    t_list += [t[i]]
    
KE_arr = np.vstack(KE_list)
U_arr = np.vstack(U_list)
E_tot_arr = np.vstack(E_tot_list)
t_arr = np.vstack(t_list)

ax6.plot(t_arr,E_tot_arr,label='Total Energy')
ax6.plot(t_arr,KE_arr,label='Kinetic Energy')
ax6.plot(t_arr,U_arr,label='Potential Energy')

ax6.set_title(r'$Energy\ vs\ Time\ For\ Orbit\ 1\ RK4\ Softened$')
ax6.set_ylabel(r'$Energy\  (E)$')
ax6.set_xlabel(r'$Time\ (\mathcal{t}$)')
ax6.legend(prop={'size': 6});

fig6.savefig("Orbit1_RK4_Soft_Energy_Plot.png")

#########################################################################################################

df=pd.read_csv('data_leap_soft.csv')
df.columns = ['t', 'x', 'y', 'z', 'vx', 'vy', 'vz', 'x2', 'y2', 'z2', 'vx2', 'vy2', 'vz2']
t = df['t']
x = df['x']
y = df['y']
z = df['z']
x2 = df['x2']
y2 = df['y2']
z2 = df['z2']
vx = df['vx']
vy = df['vy']
vz = df['vz']
vx2 = df['vx2']
vy2 = df['vy2']
vz2 = df['vz2']

KE_list = []
U_list = []
E_tot_list = []
t_list = []

fig7 = plt.figure(7,figsize=(10,8))
ax7 = fig7.add_subplot(1,1,1)
for k in range(241):
    r=((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    vr=((x[k]-x2[k])*(vx[k]-vx2[k])+(y[k]-y2[k])*(vy[k]-vy2[k])+(z[k]-z2[k])*(vz[k]-vz2[k]))/((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    ax7.scatter(vr,r)
    

ax7.set_title(r'$Leapfrog\ Orbit\ 1\ Softened\ Phase\ Plot$')
ax7.set_ylabel(r'$Distance\ (\mathcal{r}$)')
ax7.set_xlabel(r'$Velocity\ (\mathcal{v}_r$)')
fig7.savefig("Orbit1_Leapfrog_Soft_Phase_Plot.png")

fig8=plt.figure(8,figsize=(10,8))
ax8 = fig8.add_subplot(1,1,1)
for i in range(241):
    KE=(vx[i]**2+vy[i]**2+vz[i]**2)/2+(vx2[i]**2+vy2[i]**2+vz2[i]**2)/2
    U=-1/((x[i]-x2[i])**2+(y[i]-y2[i])**2+(z[i]-z2[i])**2)**(1/2)
    E_tot=KE+U
    KE_list += [KE]
    U_list += [U]
    E_tot_list += [E_tot]
    t_list += [t[i]]
    
KE_arr = np.vstack(KE_list)
U_arr = np.vstack(U_list)
E_tot_arr = np.vstack(E_tot_list)
t_arr = np.vstack(t_list)

ax8.plot(t_arr,E_tot_arr,label='Total Energy')
ax8.plot(t_arr,KE_arr,label='Kinetic Energy')
ax8.plot(t_arr,U_arr,label='Potential Energy')

ax8.set_title(r'$Energy\ vs\ Time\ For\ Orbit\ 1\ Leapfrog\ Softened$')
ax8.set_ylabel(r'$Energy\  (E)$')
ax8.set_xlabel(r'$Time\ (\mathcal{t}$)')
ax8.legend(prop={'size': 6});

fig8.savefig("Orbit1_Leapfrog_Soft_Energy_Plot.png")

print("Completed Orbit 1 Leapfrog/RK4 Phase/Energy Graphs With Softening\n")

print("Orbit 2 will plot skipping 8 data points to reduce the computation time.")
print("Data points used are thus at step sizes of 0.003 * 8 = 0.024... \n")

#########################################################################################################
# Orbit 2 No Softening
#########################################################################################################

df=pd.read_csv('data_rk4.csv')
df.columns = ['t', 'x', 'y', 'z', 'vx', 'vy', 'vz', 'x2', 'y2', 'z2', 'vx2', 'vy2', 'vz2']
t = df['t']
x = df['x']
y = df['y']
z = df['z']
x2 = df['x2']
y2 = df['y2']
z2 = df['z2']
vx = df['vx']
vy = df['vy']
vz = df['vz']
vx2 = df['vx2']
vy2 = df['vy2']
vz2 = df['vz2']

KE_list = []
U_list = []
E_tot_list = []
t_list = []

fig9 = plt.figure(9,figsize=(10,8))
ax9 = fig9.add_subplot(1,1,1)
for k in range(248,3064,8):
    r=((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    vr=((x[k]-x2[k])*(vx[k]-vx2[k])+(y[k]-y2[k])*(vy[k]-vy2[k])+(z[k]-z2[k])*(vz[k]-vz2[k]))/((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    ax9.scatter(vr,r)
    

ax9.set_title(r'$RK4\ Orbit\ 2\ No\ Softening\ Phase\ Plot$')
ax9.set_ylabel(r'$Distance\ (\mathcal{r}$)')
ax9.set_xlabel(r'$Velocity\ (\mathcal{v}_r$)')
fig9.savefig("Orbit2_RK4_Phase_Plot.png")

fig10=plt.figure(10,figsize=(10,8))
ax10 = fig10.add_subplot(1,1,1)
for i in range(248,3064,8):
    KE=(vx[i]**2+vy[i]**2+vz[i]**2)/2+(vx2[i]**2+vy2[i]**2+vz2[i]**2)/2
    U=-1/((x[i]-x2[i])**2+(y[i]-y2[i])**2+(z[i]-z2[i])**2)**(1/2)
    E_tot=KE+U
    KE_list += [KE]
    U_list += [U]
    E_tot_list += [E_tot]
    t_list += [t[i]]
    
KE_arr = np.vstack(KE_list)
U_arr = np.vstack(U_list)
E_tot_arr = np.vstack(E_tot_list)
t_arr = np.vstack(t_list)

ax10.plot(t_arr,E_tot_arr,label='Total Energy')
ax10.plot(t_arr,KE_arr,label='Kinetic Energy')
ax10.plot(t_arr,U_arr,label='Potential Energy')

ax10.set_title(r'$Energy\ vs\ Time\ For\ Orbit\ 2\ RK4\ No\ Softening$')
ax10.set_ylabel(r'$Energy\  (E)$')
ax10.set_xlabel(r'$Time\ (\mathcal{t}$)')
ax10.legend(prop={'size': 6});

fig10.savefig("Orbit2_RK4_Energy_Plot.png")

#########################################################################################################

df=pd.read_csv('data_leap.csv')
df.columns = ['t', 'x', 'y', 'z', 'vx', 'vy', 'vz', 'x2', 'y2', 'z2', 'vx2', 'vy2', 'vz2']
t = df['t']
x = df['x']
y = df['y']
z = df['z']
x2 = df['x2']
y2 = df['y2']
z2 = df['z2']
vx = df['vx']
vy = df['vy']
vz = df['vz']
vx2 = df['vx2']
vy2 = df['vy2']
vz2 = df['vz2']

KE_list = []
U_list = []
E_tot_list = []
t_list = []

fig11 = plt.figure(11,figsize=(10,8))
ax11 = fig11.add_subplot(1,1,1)
for k in range(248,3064,8):
    r=((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    vr=((x[k]-x2[k])*(vx[k]-vx2[k])+(y[k]-y2[k])*(vy[k]-vy2[k])+(z[k]-z2[k])*(vz[k]-vz2[k]))/((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    ax11.scatter(vr,r)
    

ax11.set_title(r'$Leapfrog\ Orbit\ 2\ No\ Softening\ Phase\ Plot$')
ax11.set_ylabel(r'$Distance\ (\mathcal{r}$)')
ax11.set_xlabel(r'$Velocity\ (\mathcal{v}_r$)')
fig11.savefig("Orbit2_Leapfrog_Phase_Plot.png")

fig12=plt.figure(12,figsize=(10,8))
ax12 = fig12.add_subplot(1,1,1)
for i in range(248,3064,8):
    KE=(vx[i]**2+vy[i]**2+vz[i]**2)/2+(vx2[i]**2+vy2[i]**2+vz2[i]**2)/2
    U=-1/((x[i]-x2[i])**2+(y[i]-y2[i])**2+(z[i]-z2[i])**2)**(1/2)
    E_tot=KE+U
    KE_list += [KE]
    U_list += [U]
    E_tot_list += [E_tot]
    t_list += [t[i]]
    
KE_arr = np.vstack(KE_list)
U_arr = np.vstack(U_list)
E_tot_arr = np.vstack(E_tot_list)
t_arr = np.vstack(t_list)

ax12.plot(t_arr,E_tot_arr,label='Total Energy')
ax12.plot(t_arr,KE_arr,label='Kinetic Energy')
ax12.plot(t_arr,U_arr,label='Potential Energy')

ax12.set_title(r'$Energy\ vs\ Time\ For\ Orbit\ 2\ Leapfrog\ No\ Softening$')
ax12.set_ylabel(r'$Energy\  (E)$')
ax12.set_xlabel(r'$Time\ (\mathcal{t}$)')
ax12.legend(prop={'size': 6});

fig12.savefig("Orbit2_Leapfrog_Energy_Plot.png")

print("Completed Orbit 2 Leapfrog/RK4 Phase/Energy Graphs With No Softening")

#########################################################################################################
# Orbit 2 Softened
#########################################################################################################

df=pd.read_csv('data_rk4_soft.csv')
df.columns = ['t', 'x', 'y', 'z', 'vx', 'vy', 'vz', 'x2', 'y2', 'z2', 'vx2', 'vy2', 'vz2']
t = df['t']
x = df['x']
y = df['y']
z = df['z']
x2 = df['x2']
y2 = df['y2']
z2 = df['z2']
vx = df['vx']
vy = df['vy']
vz = df['vz']
vx2 = df['vx2']
vy2 = df['vy2']
vz2 = df['vz2']

KE_list = []
U_list = []
E_tot_list = []
t_list = []

fig13 = plt.figure(13,figsize=(10,8))
ax13 = fig13.add_subplot(1,1,1)
for k in range(248,3064,8):
    r=((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    vr=((x[k]-x2[k])*(vx[k]-vx2[k])+(y[k]-y2[k])*(vy[k]-vy2[k])+(z[k]-z2[k])*(vz[k]-vz2[k]))/((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    ax13.scatter(vr,r)
    

ax13.set_title(r'$RK4\ Orbit\ 2\ Softened\ Phase\ Plot$')
ax13.set_ylabel(r'$Distance\ (\mathcal{r}$)')
ax13.set_xlabel(r'$Velocity\ (\mathcal{v}_r$)')
fig13.savefig("Orbit2_RK4_Soft_Phase_Plot.png")

fig14=plt.figure(14,figsize=(10,8))
ax14 = fig14.add_subplot(1,1,1)
for i in range(248,3064,8):
    KE=(vx[i]**2+vy[i]**2+vz[i]**2)/2+(vx2[i]**2+vy2[i]**2+vz2[i]**2)/2
    U=-1/((x[i]-x2[i])**2+(y[i]-y2[i])**2+(z[i]-z2[i])**2)**(1/2)
    E_tot=KE+U
    KE_list += [KE]
    U_list += [U]
    E_tot_list += [E_tot]
    t_list += [t[i]]
    
KE_arr = np.vstack(KE_list)
U_arr = np.vstack(U_list)
E_tot_arr = np.vstack(E_tot_list)
t_arr = np.vstack(t_list)

ax14.plot(t_arr,E_tot_arr,label='Total Energy')
ax14.plot(t_arr,KE_arr,label='Kinetic Energy')
ax14.plot(t_arr,U_arr,label='Potential Energy')

ax14.set_title(r'$Energy\ vs\ Time\ For\ Orbit\ 2\ RK4\ Softened$')
ax14.set_ylabel(r'$Energy\  (E)$')
ax14.set_xlabel(r'$Time\ (\mathcal{t}$)')
ax14.legend(prop={'size': 6});

fig14.savefig("Orbit2_RK4_Soft_Energy_Plot.png")

#########################################################################################################

df=pd.read_csv('data_leap_soft.csv')
df.columns = ['t', 'x', 'y', 'z', 'vx', 'vy', 'vz', 'x2', 'y2', 'z2', 'vx2', 'vy2', 'vz2']
t = df['t']
x = df['x']
y = df['y']
z = df['z']
x2 = df['x2']
y2 = df['y2']
z2 = df['z2']
vx = df['vx']
vy = df['vy']
vz = df['vz']
vx2 = df['vx2']
vy2 = df['vy2']
vz2 = df['vz2']

KE_list = []
U_list = []
E_tot_list = []
t_list = []

fig15 = plt.figure(15,figsize=(10,8))
ax15 = fig15.add_subplot(1,1,1)
for k in range(248,3064,8):
    r=((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    vr=((x[k]-x2[k])*(vx[k]-vx2[k])+(y[k]-y2[k])*(vy[k]-vy2[k])+(z[k]-z2[k])*(vz[k]-vz2[k]))/((x[k]-x2[k])**2+(y[k]-y2[k])**2+(z[k]-z2[k])**2)**(1/2)
    ax15.scatter(vr,r)
    

ax15.set_title(r'$Leapfrog\ Orbit\ 2\ Softened\ Phase\ Plot$')
ax15.set_ylabel(r'$Distance\ (\mathcal{r}$)')
ax15.set_xlabel(r'$Velocity\ (\mathcal{v}_r$)')
fig15.savefig("Orbit2_Leapfrog_Soft_Phase_Plot.png")

fig16=plt.figure(16,figsize=(10,8))
ax16 = fig16.add_subplot(1,1,1)
for i in range(248,3064,8):
    KE=(vx[i]**2+vy[i]**2+vz[i]**2)/2+(vx2[i]**2+vy2[i]**2+vz2[i]**2)/2
    U=-1/((x[i]-x2[i])**2+(y[i]-y2[i])**2+(z[i]-z2[i])**2)**(1/2)
    E_tot=KE+U
    KE_list += [KE]
    U_list += [U]
    E_tot_list += [E_tot]
    t_list += [t[i]]
    
KE_arr = np.vstack(KE_list)
U_arr = np.vstack(U_list)
E_tot_arr = np.vstack(E_tot_list)
t_arr = np.vstack(t_list)

ax16.plot(t_arr,E_tot_arr,label='Total Energy')
ax16.plot(t_arr,KE_arr,label='Kinetic Energy')
ax16.plot(t_arr,U_arr,label='Potential Energy')

ax16.set_title(r'$Energy\ vs\ Time\ For\ Orbit\ 2\ Leapfrog\ Softened$')
ax16.set_ylabel(r'$Energy\ (E)$')
ax16.set_xlabel(r'$Time\ (\mathcal{t}$)')
ax16.legend(prop={'size': 6});

fig16.savefig("Orbit2_Leapfrog_Soft_Energy_Plot.png")

print("Completed Orbit 2 Leapfrog/RK4 Phase/Energy Graphs With Softening\n")

print("Thank you for your patience!\n")