The code compiles, runs all the homework files, and plots the solutions using the Makefile
Additionally plots animations for the homework and 
As an added bonus: for any number of N bodies (as long as your RAM can store them all)

Type make in the linux command line to:
   compile problem1.c and problem1_softening.c with cc nrutil.c rk4.c -lm -g
   run the resulting executable files named 1 and 2
   plot the 8 animations corresponding to rk4 vs leapfrog x softening vs without x 2x eccentricity/step sizes
   plot the Phase and Energy Plots with Phase_Energy_plots.py
   plot the animation for Animated_N_Body.py -> N_Body.gif
      
      However, although Nbody_in_out_work_in_progress works for argument 1 for inputing files I am running into problems:
   
         It only does exactly what Nbody.c does currently. It is not programmed to start from a file using leapfrog.
         I may have allocated too much memory. I was attempting to dynamically create a matrix and read in only the 
         very last line of the .dat file.

         I still wanted a double pointer so I could just copy and paste from the matrix indices I used previously, but I 
         think I will change this to define my Y covariant vector with just an array instead if I can manage to only read 
         the last line of the data file. There are no good examples of how to do this easily in C that I can find. I may
         just need some rest.


Type make clean to remove all created files after running make

permanent files:        Description/Output Description:

Animated_2_Body.py      This file took me quite a long time to figure out how to make, it plots the data file from the homework

Animated_N_Body.py      This file took me several times longer to figure out even after I had the 2-body problem done
                        Indexing and looping to plot any number N masses in a 3D space was quite the challenge

HW6.pdf                 writeup of solutions with figures

Makefile                compiles and plots the following...

problem1.c              solution to question (1) outputs to data files for each method

problem1_softening.c    various softening parameters included in deriv for testing

Nbody.c                 Nbody solver for rk4 and leapfrog 

Nbody_in_out.c          Same as above (compiles with same functions) but is close to having various arguments:
                        for changing initial conditions or running from previous files (rk4 or leap)
                        Try compiling using:

                        gcc -o n_body Nbody_in_out.c nrutil.c ran1.c rk4_M.c -lm -g
                     
                        then running using: ./n_body (or whichever name you prefer to compile it under)
                        This will show more info on the arguments (1, 2, or 3) currently

Phase_Energy_plots.py   Creates Phase and Energy Plots for 8 different cases
                        Leapfrog vs RK4, no softening vs softening, and 2 different eccentricity/step sizes

nrutil.c                Numerical Recipes in C

rk4.c                   function for 4th order Runge-Kutta ODE solving method

rk4_M.c                 change to rk4 to pass masses through to deriv (gravity) used for Nbody.c & Nbody_in_out.c

*.plt                   gnuplot files to plot graphs and animations

include
 >ES_HW5.h              header for makefile (not included as there are no external functions I created, I wrote my functions before main())

nr.H                    header for Numerical Recipes


makes:
   *.csv                data files for 2-Body plots
   *.dat                data files for N-Body plots
   *.png                graphical plots
   *.gif                animations from both gnuplot and python

not in this hw,
but worth mentioning:
   *.tex                Latex file paired with .eps version to have plot with Latex
   *.eps                   "   "     "      "  .tex    "     "   "    "    "     "
                        uses command: \input{plot2_Orbits.tex}  in overleaf