import numpy as np
import matplotlib
from matplotlib import animation
from matplotlib.colors import BASE_COLORS as palette
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d.axes3d as axes3d
import pandas as pd

N=2
t_max=100

df=pd.read_csv('data_rk4.csv')

#def panda(t, m, bamboo):
    #yield np.array([bamboo.iat[time,3+7*(m-1)], bamboo.iat[time,4+7*(m-1)], bamboo.iat[time,5+7*(m-1)]])
    
############################################################################################

## Plot 3D image

fig = plt.figure()
ax = plt.axes(projection = '3d')
tt=100
a=0

for m in range(0, N):
    X_list = []
    Y_list = []
    Z_list = []
    t_list = []
    Y= []
    for t in range(1, t_max):
        X_list += [df.iloc[t,1+6*(m)]]
        Y_list += [df.iloc[t,2+6*(m)]]
        Z_list += [df.iloc[t,3+6*(m)]]
        t_list += [t]

    XX=np.vstack(X_list)
    YY=np.vstack(Y_list)
    ZZ=np.vstack(Z_list)
    #Y=[np.array(XX),np.array(YY),np.array(ZZ)]
    #Y= [XX, YY, ZZ]
    Y = [X_list, Y_list, Z_list]
    
    ax.scatter(Y[0][-1], Y[1][-1], Y[2][-1], marker = "o", s = 75, label = "mass " + str(m+1))
    ax.plot3D(Y[0][:], Y[1][:], Y[2][:], label = "tail " + str(m+1))

ax.set_xlim3d(-1, 1)
ax.set_ylim3d(-1, 1)
ax.set_zlim3d(-1, 1)
#ax.set_xlabel("x (UA)")
#ax.set_ylabel("y (UA)")
#ax.set_zlabel("z (UA)")
ax.xaxis.pane.set_edgecolor('purple')
ax.yaxis.pane.set_edgecolor('purple')
ax.zaxis.pane.set_edgecolor('purple')
ax.grid(color='p', linestyle='-', linewidth=2, alpha=0.5)
fig.patch.set_facecolor('black')
plt.axis('On')
fig.set_facecolor('black')
ax.set_facecolor('black') 
ax.grid(False) 
ax.xaxis.pane.fill = False
ax.yaxis.pane.fill = False
ax.zaxis.pane.fill = False

plt.legend()


plt.savefig("N_Body.png")

###################################################################################################

## Plot 3D animation

fig = plt.figure()
ax = plt.axes(projection = '3d')

ax.set_xlim3d(-1, 1)
ax.set_ylim3d(-1, 1)
ax.set_zlim3d(-1, 1)


trail = [10]*N


def Animate3D(k):
    for i , ligne in enumerate(lignes, 0):
        ligne.set_data(Y_full[3*i][k:max(1, k - trail[0]):-1], Y_full[1+3*i][k:max(1, k - trail[0]):-1])
        ligne.set_3d_properties(Y_full[2+3*i][k:max(1, k - trail[0]):-1])
    return lignes

Y_full = []

for m in range(0, N):
    X_list = []
    Y_list = []
    Z_list = []
    t_list = []
    Y = []
    for t in range(1, t_max):
        X_list += [df.iloc[t,1+6*(m)]]
        Y_list += [df.iloc[t,2+6*(m)]]
        Z_list += [df.iloc[t,3+6*(m)]]
        t_list += [t]

    XX=np.vstack(X_list)
    YY=np.vstack(Y_list)
    ZZ=np.vstack(Z_list)

    Y = [X_list, Y_list, Z_list]
    Y_full += Y


lignes = [ax.plot([], [], "o-", markevery = 20)[0] for _ in range(N)]

anim3D = animation.FuncAnimation(fig, Animate3D, frames = 45, interval = 10, blit = False)


#f = r"c://Users/xx/Desktop/animation.gif" 
writergif = animation.PillowWriter(fps=30)
anim3D.save("N_Body.gif", writer=writergif)

#writervideo = animation.FFMpegWriter(fps=60) 
#anim3D.save('N_Body.mov'writer=writervideo)
#anim3D.save('N_Body.avi'writer=writervideo)
