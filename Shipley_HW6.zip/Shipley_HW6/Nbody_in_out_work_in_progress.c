#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <assert.h>
#include "nrutil.h"
#include "nr.h"

//Article on tree code https://articles.adsabs.harvard.edu/pdf/1987ApJS...64..715H

#define N 400   // number of masses
#define N_STEPS 300 // number of iterations (rows of data) x dt = total time
#define R_AVG 20 // Distance of a mass from central black hole on average (for generating 2D doughnut)
#define SPREAD 15 // Spread of radial distance of a mass from R_AVG (for generating 2D doughnut)
#define N_ORBITS 0.1   // number of orbits a mass would make if at A_MAX (determines step size)
                      // more orbits means larger t_max and larger step size to get to t_max

FILE *fpt_rk4_N;
FILE *fpt_rk4_N_new;
FILE *fpt_leap_N;
FILE *fpt_init;

void deriv(float t, float y[], float dr[], float M[]){
  float dx, dy, dz, accx, accy, accz, mag, soft, soft2, soft3;
  for (int i=1; i<=N; ++i){
    accx=accy=accz=0.0;
    float r_avg=R_AVG;
    float G = 4.3e-3;
    float G_si = 6.67e-11;
    soft=0.1*r_avg/3;    // a[1] ~= 0.47    https://home.ifa.hawaii.edu/users/barnes/research/smoothing/soft.pdf
    soft2=0.98*pow(N,-0.28);  //Plummer     https://arxiv.org/abs/astro-ph/9912467
    float soft_check; 
    if (soft>soft2){
      soft_check=soft;
    }
    else{
      soft_check=soft2;
    }
    for (int j=1; j<=N; ++j){
      if (i != j){
        dx=y[1+6*(i-1)]-y[1+6*(j-1)];
        dy=y[3+6*(i-1)]-y[3+6*(j-1)];
        dz=y[5+6*(i-1)]-y[5+6*(j-1)];
        mag=pow(dx*dx+dy*dy+dz*dz+soft2*soft2,1.5);
        accx=accx-dx*M[i]*M[j]*G/(mag);
        accy=accy-dy*M[i]*M[j]*G/(mag);
        accz=accz-dz*M[i]*M[j]*G/(mag);
      }
    }
    dr[1+6*(i-1)]=y[2+6*(i-1)];
    dr[2+6*(i-1)]=accx;
    dr[3+6*(i-1)]=y[4+6*(i-1)];
    dr[4+6*(i-1)]=accy;
    dr[5+6*(i-1)]=y[6+6*(i-1)];
    dr[6+6*(i-1)]=accz;
    M[i]=M[i];
  }
}

void leapfrog(float y[], float dydx[], int n, float x, float h, float M[], float yout[],
	void (*derivs)(float, float [], float [], float []))
{
  float xh=x+h/2;
  for (int i=1;i<=n;i=i+2){
    y[i+1] = y[i+1]+h/2*dydx[i+1];
  }
  for (int i=1;i<=n;i=i+2){
    yout[i] = y[i] + h * y[i+1];
  }
  (*deriv)(xh,yout,dydx,M);
  for (int i=1;i<=n;i=i+2){
    yout[i+1]=y[i+1]+h/2*dydx[i+1];
    M[i]=M[i];
  }
}

double vectorMag(float x[], int n){
    float sum=0.0;

    for(int i = 0; i < n; i++) {
        sum += x[i]*x[i];
    }
    return sqrt(sum);
}

void getPoint(float x,float y,float z){
    long idum=554455;
    float d;
    d=0.0;
    while (d<1.0){
      x = ran1(&idum) * 2.0 - 1.0;
      y = ran1(&idum) * 2.0 - 1.0;
      z = ran1(&idum) * 2.0 - 1.0;
      d= x*x + y*y + z*z;
    }
}

double **readmatrix(size_t *rows, size_t *cols, const char *filename)
{
    if(rows == NULL || cols == NULL || filename == NULL)
        return NULL;

    *rows = 0;
    *cols = 0;

    FILE *fp = fopen(filename, "r");

    if(fp == NULL)
    {
        fprintf(stderr, "could not open %s\n", filename);
        return NULL;
    }

    double **mat = NULL, **tmp;

    char line[20480];

    while(fgets(line, sizeof line, fp))
    {
        if(*cols == 0)
        {
            // determine the size of the columns based on
            // the first row
            char *scan = line;
            double dummy;
            int offset = 0;
            while(sscanf(scan, "%lg%n", &dummy, &offset) == 1)
            {
                scan += offset;
                (*cols)++;
            }
        }

        tmp = realloc(mat, (*rows + 1) * sizeof *mat);

        if(tmp == NULL)
        {
            fclose(fp);
            return mat; // return all you've parsed so far
        }

        mat = tmp;

        mat[*rows] = calloc(*cols, sizeof *mat[*rows]);

        if(mat[*rows] == NULL)
        {
            fclose(fp);
            if(*rows == 0) // failed in the first row, free everything
            {
                fclose(fp);
                free(mat);
                return NULL;
            }

            return mat; // return all you've parsed so far
        }

        int offset = 0;
        char *scan = line;
        for(size_t j = 0; j < *cols; ++j)
        {
            if(sscanf(scan, "%lg%n", mat[*rows] + j, &offset) == 1)
                scan += offset;
            else
                mat[*rows][j] = 0; // could not read, set cell to 0
        }

        // incrementing rows
        (*rows)++;
    }

    fclose(fp);

    return mat;
}

double **readlastrow(size_t *rows, size_t *cols, const char *filename)
{
    if(rows == NULL || cols == NULL || filename == NULL)
        return NULL;

    *rows = 0;
    *cols = 0;

    FILE *fp = fopen(filename, "r");

    if(fp == NULL)
    {
        fprintf(stderr, "could not open %s\n", filename);
        return NULL;
    }

    double **mat = NULL, **tmp;

    char line[20480];

    while(fgets(line, sizeof line, fp))
    {
        if(*cols == 0)
        {
            // determine the size of the columns based on
            // the first row
            char *scan = line;
            double dummy;
            int offset = 0;
            while(sscanf(scan, "%lg%n", &dummy, &offset) == 1)
            {
                scan += offset;
                (*cols)++;
            }
        }

        tmp = realloc(mat, (*rows + 1) * sizeof *mat);

        if(tmp == NULL)
        {
            fclose(fp);
            return mat; // return all you've parsed so far
        }

        mat = tmp;

        mat[*rows] = calloc(*cols, sizeof *mat[*rows]);

        if(mat[*rows] == NULL)
        {
            fclose(fp);
            if(*rows == 0) // failed in the first row, free everything
            {
                fclose(fp);
                free(mat);
                return NULL;
            }

            return mat; // return all you've parsed so far
        }

        int offset = N_STEPS-1;
        char *scan = line;
        for(size_t j = 0; j < *cols; ++j)
        {
            if(sscanf(scan, "%lg%n", mat[*rows] + j, &offset) == 1)
                scan += offset;
            else
                mat[*rows][j] = 0; // could not read, set cell to 0
        }

        // incrementing rows
        (*rows)++;
    }

    fclose(fp);

    return mat;
}
/*
void TimeDyn(int n, int i) {
  int j=1, k, m;
  float **A;
  double dt[n][n], d_t[n*n], mflops[n][n], sum[2]; 
  float t0, mflop_avg;
  t0 = getCPU();   /* get init value 

  A = (float **) malloc(m*sizeof(float *));
  assert(A);
  for (k = 0; k < n; ++k) {
    A[k] = (float *) malloc(n*sizeof(float));
    assert(A[k]);
  }
  for (k = 0; k < n; ++k) {
    for (m = 0; m < n; ++m){
      A[k][m] += 5.0;
      //dt[k][m] = getCPU() - t0;
      //mflops[k][m] = j/dt[k][m]/1e6;
      ++j;
      //sum[i] += mflops[k][m];
    }
  }
  for (k = 0; k < n; k++){
    free((void *) A[k]);
  }
  free((void *) A);
  fclose(fpt);
}
*/

/*
void read_rk4(float M[], float y[]){
    //Read in Data from RK4
    int m, k, j=1;
    float t_f;
    float **r;
    fpt_rk4_N=fopen("data_rk4_NBody.dat", "w+");
    r = (float **) malloc(m*sizeof(float *)); // allocate memory for number of columns
    assert(r);
    for (k = 0; k < N; ++k) {
      r[k] = (float *) malloc((N*7+1)*sizeof(float));
      assert(r[k]);
    }
    for (k = 0; k < N_STEPS; ++k) {
      while (k < N_STEPS){
          fscanf(fpt_rk4_N, "%*[^\n]\n"); //Skip to the end of the rows k
      }
      for (m = 0; m < N; ++m){
        if (m==1){
          fscanf(fpt_rk4_N,"%f ", &t_f);
        }
        fscanf(fpt_rk4_N,"%f ",  &r[0][1+7*(m-1)]);
        fscanf(fpt_rk4_N,"%f %f %f %f %f %f ", &r[0][2+7*(m-1)], &r[0][3+7*(m-1)], &r[0][4+7*(m-1)], &r[0][5+7*(m-1)], &r[0][6+7*(m-1)], &r[0][7+7*(m-1)]);
      }
    }
    printf("%g %g %g %g %g %g %g %g", r[N_STEPS][0], r[N_STEPS][1], r[N_STEPS][2], r[N_STEPS][3], r[N_STEPS][4], r[N_STEPS][5], r[N_STEPS][6], r[N_STEPS][7]);
    fclose(fpt_rk4_N);
    char nf=("data_rk4_NBody_%g.dat",t_f);
    rename("data_rk4_NBody.dat", "nf");
    for (int m=1; m <= N; ++m){
      M[m]=(r[0][1+7*(m-1)]); //set M[m]
      y[1+6*(m-1)]=(r[0][2+7*(m-1)]); //set x_o[m]
      y[2+6*(m-1)]=(r[0][3+7*(m-1)]); //set vx_o[m]
      y[3+6*(m-1)]=(r[0][4+7*(m-1)]); //set y_o[m]
      y[4+6*(m-1)]=(r[0][5+7*(m-1)]); //set vy_o[m]
      y[5+6*(m-1)]=(r[0][6+7*(m-1)]); //set z_o[m]
      y[6+6*(m-1)]=(r[0][7+7*(m-1)]); //set vz_o[m]
    }
    printf("\n\n");
    printf("Initial Conditions for Black Hole: M = %g, pos = <%g, %g, %g>, vel = <%g, %g, %g>\n\n", r[0][1], r[0][2], r[0][3], r[0][4], r[0][5], r[0][6], r[0][7]);
    printf("Initial Conditions for first mass: M = %g, pos = <%g, %g, %g>, vel = <%g, %g, %g>\n\n", r[0][8], r[0][9], r[0][10], r[0][11], r[0][12], r[0][13], r[0][14]);
}
*/

int main(int argc,char *argv[]){
  //float vol=10.0*10.0*10.0; //Volume of the sampled region.

  long idum=554455;  // ran1 seed
  float t_max, dt, w_max;
  /*
  w_max = frequency based on maximum possible semi major axis of a mass orbiting a central blackhole (for calulating timestep)
  t_max = total time based on N_ORBITS and the angular frequency of a mass orbiting a central black hole
  dt = stepsize based on t_max and N_ORBIT
  */
  float R, theta, phi; //Initial r, theta, phi generated values for mass (m)
  float v_vec[3], e_r[3], e_theta[3], e_phi[3], e_theta_dot[3],  e_phi_dot[3]; // Spherical orthonormal basis vectors tangent to the corresponding coordinate lines
  float v_o; //Initial orbital velocity for mass (m) orbiting a central black hole
  float v_phi, v_theta; //For possible random initial tangential velocities to sphere
  float P; // Orbital Period of mass[m]
  float M_i[N]; //To generate random masses
  float x_i[N],y_i[N],z_i[N]; //Initial x, y, z calculated from r, phi, and theta for mass (m)
  float vx_i[N], vy_i[N], vz_i[N]; //Initial vx, vy, vz
  float r_x[N], r_y[N], r_z[N], v_x[N], v_y[N], v_z[N]; //Initial variables read in for mass (m)
  // float r_x2[N], r_y2[N], r_z2[N], v_x2[N], v_y2[N], v_z2[N]; //Initial variables read in for mass (m even)
  
  // Variables for RK4 and Leapfrog calls
  int n_eqs= (int) 6*N; 
  float t; //time at current step
  float *y=vector(1, n_eqs); //store next position and velocity for mass[m]
  float *dydx=vector(1, n_eqs); //used calculate gravitational force and couple the equations of motion inside deriv functiion
  float *M=vector(1, N); //To give rk4, leapfrog, and deriv the array of masses
  
  float r_avg = R_AVG;
  w_max = sqrt(2/(r_avg*r_avg*r_avg));
  t_max = N_ORBITS*2*M_PI/w_max;
  dt = ceilf(t_max/N_STEPS * 100) / 100;

  int a;

  if (argc <= 1 ) {
      printf("\nUsage Error: %s takes argument\n\n int n = \n",argv[0]);
      printf("1 -> Generate Supernova Like Initial Conditions\n");
      printf("2 -> Rerun from last RK4 file output (Work In Progress)\n");
      printf("3 -> Rerun from last Leapfrog file output (Getting There Next)\n\n");
      printf("\t Using previous file looks for last line in file based on N_STEPS defined at top of file\n");
      printf("\t Set N_STEPS to row count in file if they are different\n");
      printf("\t Note N must be the same from the last run also. N should equal (columns-1)/7\n");
      return 1;
    } 
  a = atoi(argv[1]); /* convert strings to integers */

  printf("\nParameters Used:\n");
  printf("\nN: %d\n", N);
  printf("\nN_STEPS: %d\n", N_STEPS);
  printf("\nR_AVG: %g\n", (float) R_AVG);
  printf("\nSPREAD: %g\n", (float) SPREAD);
  printf("\nN_ORBITS: %g\n", (float) N_ORBITS);

if (atoi(argv[1]) == 1){
    //Generate Initial Conditons
    fpt_init=fopen("data_init.dat", "w+");
    fprintf(fpt_init,"%g ", 0.0);
    for(int m=0; m<N; m++){
      //    Set initial conditions for Black Hole
      if (m==0){
        M_i[m]=4e6;
        x_i[m]=0.0;
        y_i[m]=0.0;
        z_i[m]=0.0;
        vx_i[m] = 0.0;
        vy_i[m] = 0.0;
        vz_i[m] = 0.0;
      }
      //    Set initial conditions for each mass
      else{
        M_i[m] = 1.0;
        M_i[m] = 2+2*ran1(&idum);

        //Try different methods for generating bodies
        //Just here to mess with choosing R first
        //x_i[m] = R * cos(theta) * sin(phi);
        //y_i[m] = R * sin(theta) * sin(phi);
        //z_i[m] = R * cos(phi);
        //getPoint(x_i[m], y_i[m], z_i[m]); (not functional)
        
        //  Set radius to random point in spherical shell using discard values method
        //  set while loop to R<1.0 and set all values to ran*2-1 inside loop to get points in unit sphere
        /*
        R=0.0;
        while (R<1.0+A_MIN){
          x_i[m] = ran1(&idum) * A_MAX - 1.0 - A_MIN;
          y_i[m] = ran1(&idum) * A_MAX - 1.0 - A_MIN;
          z_i[m] = ran1(&idum) * A_MAX - 1.0 - A_MIN;
          R = x_i[m]*x_i[m] + y_i[m]*y_i[m] + z_i[m]*z_i[m];
        }
        x_i[m] = x_i[m]; // For resetting maximum radius (ie times 100)
        y_i[m] = y_i[m];
        z_i[m] = z_i[m];
        */
        
        //   Random Doughnut Coordinates
        //theta=2*M_PI;
        //while (theta==2*M_PI);{
          theta = 2*M_PI*ran1(&idum);
        //}
        float b = ran1(&idum)*(R_AVG+SPREAD)+R_AVG;
        x_i[m] = b * cos(theta);
        y_i[m] = b * sin(theta);
        z_i[m] = 0;
        R= x_i[m]*x_i[m]+y_i[m]*y_i[m];
        //theta=1/tan(y_i[m]/x_i[m]);

        //   Kepler's Law With Standard Galactic Units
        float G = 4.3e-3;
        float P_sq=4*M_PI*M_PI*pow(R,3)/((M_i[0]+M_i[m])*G);
        P=sqrt(P_sq);

        // Trying enclosed mass for galactic disk where M proportional to r
        //float M_enclosed = R/(R_AVG+SPREAD)*(3*N+M_i[0]); //normalize r and multiply by Mr for accurate units
        //v_o=sqrt(G*M_enclosed/R);

        // Trying enclosed mass for galactic disk where M proportional to r^3
        //float M_enclosed = R/(R_AVG)*(R_AVG)*(R_AVG)*(3*N+M_i[0]);
        //v_o=sqrt(G*M_enclosed/R);

        //   Kepler's Law With Standard Solar Units
        //float AU_per_pc=206265;
        //float R_AU=R*AU_per_pc;
        //float P_sq=pow(AU_per_pc*R,3)/(M_i[0]+M_i[m]);
        //P = sqrt(P_sq)*86400*365.1;
        //x_i[m] = x_i[m]* AU_per_pc;
        //y_i[m] = x_i[m]* AU_per_pc;
        //   Different units for period
        //float Mb_si=M_i[0]*2e30;
        //float G_si=6.74e-11;
        //float R_si=R*(3.086e+13);
        //P=2*M_PI*pow(R_si*R_si,0.75)/(pow(((Mb_si+M_i[m])*2e30)*G_si,0.5));

        //int nsteps=(int)N_ORBITS*P/dt; //If changing from a given number of steps to instead a given timestep then comment dt
        
        //  ----- DIFFERERNT UNITS AND METHODS FOR ORBITAL VELOCITY -----
        // --- Galactic 1 ---
        v_o=2*M_PI*R/P;
        // --- Galactic 2 ---
        //v_o=sqrt(2*G*(M_i[0])*(1/R-1/R_AVG));
        // --- Galactic 3 ---
        //v_o=sqrt(G*0.5*pow(N,3)/(2*M_PI*R));
        //  --- SI ---
        //float v_si=pow(2*G_si*2e30*(M_i[0]+M_i[m])/(pow(R_si*R_si,0.5)),0.5);
        //v_o=2*M_PI*R_si/P/3.2407e-14; 
        //x_i[m]=x_i[m]*(3.086e+16);  //  (converting other variables to SI...)
        //y_i[m]=y_i[m]*(3.086e+16);
        //z_i[m]=z_i[m]*(3.086e+16);
        //M_i[m]=M_i[m]*2e30;

        // Trying to randomly partition portions of v_o to v_theta and v_phi (both perpendicular to R)
        //v_theta = -v_o+2*v_o*ran1(&idum); //Portion of orbital speed tp v_theta    
        //v_phi = v_o-v_theta; //Remaining orbital speed to v_phi
                              //radial speed should be 0

        //   Radial vector in spherical
        //e_r[0] = cos(theta) * sin(phi);
        //e_r[1] = sin(theta) * sin(phi);
        //e_r[2] = cos(phi);
        //   Tangent vectors to R in radial
        e_theta[0] = -sin(theta);     //same in cylindrical
        e_theta[1] = cos(theta);      //same in cylindrical
        //e_theta[2] = 0;
        //e_phi[0] = cos(theta) * cos(phi);
        //e_phi[1] = sin(theta) * cos(phi);
        //e_phi[2] = -sin(phi);

        // Cylindrical e_r
        e_r[0] = cos(theta);
        e_r[1] = sin(theta);
        
        //  To define e_theta_dot and e_phi_dot 
        // (Equations to calculate orbital velocity such as with RK4 in deriv in a spherical coordinate system)
        /*
        for (int i=0; i<=2; ++i){
          e_theta_dot[i] = -2*M_PI/P * sin(phi) * e_r[i] - 2*M_PI/P * cos(phi) * e_phi[i];
          e_phi_dot[i] = -2*M_PI/P * e_r[i] + 2*M_PI/P * cos(phi) * e_phi[i];
        }
        */

        //  To define orbital velocity in spherical
        /*
        for (int i=0; i<=2; ++i){
          v_vec[i] = R * 2*M_PI/P * sin(phi) * e_theta[i] + R * 2*M_PI/P * e_phi[i];
        }
        float vx = v_vec[0];
        float vy = v_vec[1];
        float vz = v_vec[2];
        */

        //   Try various methods defining orbital velocity converted to Cartesian
        //   ---Spherical---
        //vx_i[m] = - v_o * cos(theta+M_PI/2) * sin(phi+M_PI/2);
        //vy_i[m] = - v_o * sin(theta+M_PI/2) * sin(phi+M_PI/2);
        //vz_i[m] = - v_o * cos(phi+M_PI/2);

        //   ---Random spherical velocities--- 
        //vx_i[m] = -v_o+2*v_o*ran1(&idum); //Portion of orbital speed      
        //vy_i[m] = (v_o-vx_i[m])+2*(v_o-vx_i[m])*ran1(&idum); //Portion of remaining orbital speed
        //vz_i[m] = v_o-vx_i[m]-vy_i[m]; //Final remaining orbital speed

        //   ---Random circular velocities--- 
        //vx_i[m] = -v_o * cos(theta);
        //vy_i[m] = vx_i[m] -v_o ;
        //vz_i[m] = 0.0;

        //   ---Disk Galaxy: Even orbital velocity v^2 = 2 x GM/R (equal angular velocities)
        //vx_i[m] = -v_o * sin(theta+M_PI/2);
        //vy_i[m] = v_o * cos(theta);
        vz_i[m] = 0.0;

        vx_i[m] = R*2*M_PI/P*e_theta[0];
        vy_i[m] = R*2*M_PI/P*e_theta[1];

      }

      if (m==1){
        printf("Calculated Values:\n");
        printf("w_max = %g\n", w_max);
        printf("t_max = %g\n", t_max);
        printf("dt = %g\n\n", dt);

        printf("Initial Values for mass 1:\n");

        printf("M_i = %g\n",M_i[1]);
        printf("x_i = %g\n",x_i[1]);
        printf("y_i = %g\n",y_i[1]);
        printf("z_i = %g\n",z_i[1]);
        printf("v_o = %g\n",v_o);
        printf("vx_i = %g\n",vx_i[1]);
        printf("vy_i = %g\n",vy_i[1]);
        printf("vz_i = %g\n",vz_i[1]);
      }

      fprintf(fpt_init,"%g %g %g %g %g %g %g ", M_i[m], x_i[m], vx_i[m], y_i[m], vy_i[m], z_i[m], vz_i[m]);
    }
    fclose(fpt_init);
  
    //Read in Data from Generated Initial Conditions
    size_t cols, rows;
    double **r = readmatrix(&rows, &cols, "data_init.dat");

    if(r == NULL)
    {
        fprintf(stderr, "could not read matrix\n");
        return 1;
    }
    //printf("\ndata row count: %ld", rows);
    printf("\ndata col count check: (N_masses-1)/7 = %ld", cols);
    
    for (int m=1; m <= N; ++m){
      M[m]=(r[0][1+7*(m-1)]); //set M[m]
      y[1+6*(m-1)]=(r[0][2+7*(m-1)]); //set x_o[m]
      y[2+6*(m-1)]=(r[0][3+7*(m-1)]); //set vx_o[m]
      y[3+6*(m-1)]=(r[0][4+7*(m-1)]); //set y_o[m]
      y[4+6*(m-1)]=(r[0][5+7*(m-1)]); //set vy_o[m]
      y[5+6*(m-1)]=(r[0][6+7*(m-1)]); //set z_o[m]
      y[6+6*(m-1)]=(r[0][7+7*(m-1)]); //set vz_o[m]
    }
    printf("\n\n");
    printf("Initial Conditions for Black Hole: M = %g, pos = <%g, %g, %g>, vel = <%g, %g, %g>\n\n", r[0][1], r[0][2], r[0][4], r[0][6], r[0][3], r[0][5], r[0][7]);
  }

//   Read in Data from RK4
  if (atoi(argv[1]) == 2){
    float t_f;
    //read_rk4(M, y); (work in progress to read data from my own function to only read last row of data)

    //   Read in Data from Generated Initial Conditions
    size_t cols, rows;
    double **r = readmatrix(&rows, &cols, "data_init.dat"); //(attempting using modified version of readmatrix)

    if(r == NULL)
    {
        fprintf(stderr, "could not read matrix\n");
        return 1;
    }
    printf("\ndata row count: %ld", rows);
    printf("\ndata col count: %ld", cols);

    for (int m=1; m <= N; ++m){
      t_f =  (r[0][0]);
      M[m]=(r[0][1+7*(m-1)]); //set M[m]
      y[1+6*(m-1)]=(r[0][2+7*(m-1)]); //set x_o[m]
      y[2+6*(m-1)]=(r[0][3+7*(m-1)]); //set vx_o[m]
      y[3+6*(m-1)]=(r[0][4+7*(m-1)]); //set y_o[m]
      y[4+6*(m-1)]=(r[0][5+7*(m-1)]); //set vy_o[m]
      y[5+6*(m-1)]=(r[0][6+7*(m-1)]); //set z_o[m]
      y[6+6*(m-1)]=(r[0][7+7*(m-1)]); //set vz_o[m]
    }
    fclose(fpt_rk4_N);
    char nf=("data_rk4_NBody_%g.dat",t_f);
    rename("data_rk4_NBody.dat", "nf");

    printf("\n\n");
    
    printf("%g %g %g %g %g %g %g %g", r[N_STEPS][0], r[N_STEPS][1], r[N_STEPS][2], r[N_STEPS][3], r[N_STEPS][4], r[N_STEPS][5], r[N_STEPS][6], r[N_STEPS][7]);
  }

  if (atoi(argv[1]) == 2){
    
  }

  //RK4 solution
  t=0.0;
  //nsteps = (int)t_max/h[k];
  printf("nsteps = %d \n\n", N_STEPS);
  fpt_rk4_N_new=fopen("data_rk4_NBody.dat", "w+");
  for(int j=1; j<=N_STEPS; ++j){
    deriv(t, y, dydx, M);
    rk4_M(y, dydx, n_eqs, t, dt, M, y, *deriv);
    t=j*dt;
    fprintf(fpt_rk4_N_new,"%g ", t);
    for(int m=1; m<=N; m++){
      fprintf(fpt_rk4_N_new,"%g %g %g %g %g %g %g ", M[m], y[1+6*(m-1)], y[2+6*(m-1)], y[3+6*(m-1)], y[4+6*(m-1)], y[5+6*(m-1)], y[6+6*(m-1)]);
      if (j==1 && m==2){
         printf("Check Conditions for mass 1 at t = 1: M = %g, pos = <%g, %g, %g>, vel = <%g, %g, %g>\n\n", M[m], y[7*(m-1)],  y[2+7*(m-1)], y[4+7*(m-1)], y[1+7*(m-1)], y[3+7*(m-1)], y[5+7*(m-1)]);
      }
    }
    fprintf(fpt_rk4_N_new,"\n");
  }
  fclose(fpt_rk4_N_new);

/*
  //Leapfrog Solution

  for (int m=1; m <= N; ++m){
      M[m]=(r[0][1+7*(m-1)]); //set M[m]
      y[1+6*(m-1)]=(r[0][2+7*(m-1)]); //set x_o[m]
      y[2+6*(m-1)]=(r[0][3+7*(m-1)]); //set vx_o[m]
      y[3+6*(m-1)]=(r[0][4+7*(m-1)]); //set y_o[m]
      y[4+6*(m-1)]=(r[0][5+7*(m-1)]); //set vy_o[m]
      y[5+6*(m-1)]=(r[0][6+7*(m-1)]); //set z_o[m]
      y[6+6*(m-1)]=(r[0][7+7*(m-1)]); //set vz_o[m]
  }

  t=0.0;
  //nsteps = (int)t_max/h[k];
  printf("  nsteps = %d \n\n", N_STEPS);
  fpt_leap_N=fopen("data_leap_NBody.dat", "w+");
  for(int j=1; j<=N_STEPS; ++j){
    deriv(t,y,dydx, M);
    leapfrog(y, dydx, n_eqs, t, dt, M, y, *deriv);
    t=j*dt;
    fprintf(fpt_leap_N,"%g ", t);
    for(int m=1; m<=N; m++){
      fprintf(fpt_leap_N,"%g %g %g %g %g %g %g ", M[m], y[1+6*(m-1)], y[2+6*(m-1)], y[3+6*(m-1)], y[4+6*(m-1)], y[5+6*(m-1)], y[6+6*(m-1)]); 
    }
    fprintf(fpt_leap_N,"\n");
  }

  free_vector(y,1,n_eqs);
  free_vector(dydx,1,n_eqs);
  free_vector(M,1,n_eqs);
  fclose(fpt_leap_N);
*/
    // freeing memory
    //for(size_t i = 0; i < N_STEPS; ++i){
      //free(r[i]);
    //}
    //free(r);
    return 0;
}