#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <assert.h>
#include "nrutil.h"
#include "nr.h"

//Article on tree code https://articles.adsabs.harvard.edu/pdf/1987ApJS...64..715H


#define N 2 //number of masses
#define N_ORBITS 5 //number of orbits

FILE *fpt_rk4_soft;
FILE *fpt_leap_soft;

void deriv(float t, float y[], float dr[]){
  float dx, dy, dz, accx, accy, accz, mag, soft, soft2, soft3;
  for (int i=1; i<=N; ++i){
    accx=accy=accz=0.0;
    soft=0.1*0.47/3;    // a[1] ~= 0.47    https://home.ifa.hawaii.edu/users/barnes/research/smoothing/soft.pdf
    soft2=0.1*0.26/3;    // a[2] ~= 0.26 
    soft3=0.98*pow(N,-0.28);  //Plummer    https://arxiv.org/abs/astro-ph/9912467
    for (int j=1; j<=N; ++j){
      if (i != j){
        dx=y[1+6*(i-1)]-y[1+6*(j-1)];
        dy=y[3+6*(i-1)]-y[3+6*(j-1)];
        dz=y[5+6*(i-1)]-y[5+6*(j-1)];
        mag=pow(dx*dx+dy*dy+dz*dz+soft*soft,1.5);
        accx=accx-dx/mag;
        accy=accy-dy/mag;
        accz=accz-dz/mag;
      }
    }
    dr[1+6*(i-1)]=y[2+6*(i-1)];
    dr[2+6*(i-1)]=accx;
    dr[3+6*(i-1)]=y[4+6*(i-1)];
    dr[4+6*(i-1)]=accy;
    dr[5+6*(i-1)]=y[6+6*(i-1)];
    dr[6+6*(i-1)]=accz;
  }
}

void leapfrog(float y[], float dydx[], int n, float x, float h, float yout[],
	void (*derivs)(float, float [], float []))
{
  float xh=x+h/2;
  for (int i=1;i<=n;i=i+2){
    y[i+1] = y[i+1]+h/2*dydx[i+1];
  }
  for (int i=1;i<=n;i=i+2){
    yout[i] = y[i] + h * y[i+1];
  }
  (*deriv)(xh,yout,dydx);
  for (int i=1;i<=n;i=i+2){
    yout[i+1]=y[i+1]+h/2*dydx[i+1];
  }
}

double **readmatrix(size_t *rows, size_t *cols, const char *filename)
{
    if(rows == NULL || cols == NULL || filename == NULL)
        return NULL;
    *rows = 0;
    *cols = 0;
    FILE *fp = fopen(filename, "r");

    if(fp == NULL)
    {
        fprintf(stderr, "could not open %s\n", filename);
        return NULL;
    }

    double **mat = NULL, **tmp;
    char line[1024];

    while(fgets(line, sizeof line, fp))
    {
        if(*cols == 0)
        {
            // determine the size of the columns based on
            // the first row
            char *scan = line;
            double dummy;
            int offset = 0;
            while(sscanf(scan, "%lg%n", &dummy, &offset) == 1)
            {
                scan += offset;
                (*cols)++;
            }
        }

        tmp = realloc(mat, (*rows + 1) * sizeof *mat);

        if(tmp == NULL)
        {
            fclose(fp);
            return mat; // return all you've parsed so far
        }

        mat = tmp;
        mat[*rows] = calloc(*cols, sizeof *mat[*rows]);

        if(mat[*rows] == NULL)
        {
            fclose(fp);
            if(*rows == 0) // failed in the first row, free everything
            {
                fclose(fp);
                free(mat);
                return NULL;
            }

            return mat; // return all you've parsed so far
        }

        int offset = 0;
        char *scan = line;
        for(size_t j = 0; j < *cols; ++j)
        {
            if(sscanf(scan, "%lg%n", mat[*rows] + j, &offset) == 1)
                scan += offset;
            else
                mat[*rows][j] = 0; // could not read, set cell to 0
        }

        // incrementing rows
        (*rows)++;
    }
    fclose(fp);
    return mat;
}

int main(){
  float t_max, a[2], v[N][2], t, dt, w, P[2]; 
  /*
  t_max = total time if desiring to define time step based on t_max and N_ORBITS (currently unused)
  a = semi-major axis
  v[m][k] = initial velocity for each particle [m] and each time step [k]
  t = time at current step
  dt = stepsize if desiring to define time step based on t_max and N_ORBITS (currently unused)
  w = freq 1/P  "     "      "  "       "    "    "    "   "    "     "         "         "
  P = Orbital Period
  */
  float x0[2]={-0.5,0.5}; //Initial x values for each particle
  float h[2]={0.05,0.003};
  float r_x[N], r_y[N], r_z[N], v_x[N], v_y[N], v_z[N]; //Initial variables for particle 1
  float r_x2[N], r_y2[N], r_z2[N], v_x2[N], v_y2[N], v_z2[N]; //Initial variables for particle 2
  float e[2]={0.5,0.9}; // eccentricity[k] varies per stepsize
  int nsteps[2], n_eqs=12;
  
  float *y=vector(1, n_eqs);
  float *dydx=vector(1, n_eqs);


//Generate Initial Conditions
  for(int k=0; k<=1; k++){
    a[k]=0.5/(1+e[k]);
    //w = sqrt(2/(a[k]*a[k]*a[k]));
    //t_max = N_ORBITS*2*M_PI/w;
    //dt = t_max/N_STEPS;
    P[k]=4*M_PI*pow(a[k],1.5);
    nsteps[k]=(int)N_ORBITS*P[k]/h[k];
    for(int m=1; m<=N; m++){
      if (m==1){
        v[m-1][k]=pow(2*a[k]-0.5,0.5)/pow(a[k]*0.5,0.5);
      }
      else{
        v[m-1][k]=-pow(2*a[k]-0.5,0.5)/pow(a[k]*0.5,0.5);
      }
    }
  }

  size_t cols, rows;
  double **r = readmatrix(&rows, &cols, "data_init.dat");

  if(r == NULL)
  {
      fprintf(stderr, "could not read matrix\n");
      return 1;
  }
  printf("\ndata row count: %ld", rows);
  printf("\ndata col count: %ld", cols);
  
  for(size_t i = 0; i < rows; ++i){
    r_x[i]=(r[i][0]);
    r_y[i]=(r[i][1]);
    r_z[i]=(r[i][2]);
    v_x[i]=(r[i][3]);
    v_y[i]=(r[i][4]);
    v_z[i]=(r[i][5]);
    r_x2[i]=(r[i][6]);
    r_y2[i]=(r[i][7]);
    r_z2[i]=(r[i][8]);
    v_x2[i]=(r[i][9]);
    v_y2[i]=(r[i][10]);
    v_z2[i]=(r[i][11]);
  }
  
  printf("\n\n");
  printf("Initial Conditions stepsize(0.05) & eccentricity(0.5): -> particle1 <%g, %g, %g, %g, %g, %g>, particle2 <%g, %g, %g, %g, %g, %g> \n\n", r_x[0], r_y[0], r_z[0], v_x[0], v_y[0], v_z[0],
  r_x2[0], r_y2[0], r_z2[0], v_x2[0], v_y2[0], v_z2[0]);
  printf("Initial Conditions: stepsize(0.003) & eccentricity(0.9) -> particle1 <%g, %g, %g, %g, %g, %g>, particle2 <%g, %g, %g, %g, %g, %g> \n\n", r_x[1], r_y[1], r_z[1], v_x[1], v_y[1], v_z[1],
  r_x2[1], r_y2[1], r_z2[1], v_x2[1], v_y2[1], v_z2[1]);

  
  //RK4 Solution
  fpt_rk4_soft=fopen("data_rk4_soft.csv", "w+");
  for(int k=0; k<=1; k++){
    t=0.0;
    //nsteps = (int)t_max/h[k];
    printf("Orbital Period %d: %g \n",k+1,P[k]);
    printf("  nsteps = %d \n\n", nsteps[k]);

    for(int m=1; m<=N; m++){
      if(m % 2 == 0){
        y[1+6*(m-1)]=r_x2[k]; //x0_2
        y[2+6*(m-1)]=v_x2[k]; //vx0_2
        y[3+6*(m-1)]=r_y2[k]; //y0_2
        y[4+6*(m-1)]=v_y2[k]; //vy0_2
        y[5+6*(m-1)]=r_z2[k]; //z0_2
        y[6+6*(m-1)]=v_z2[k]; //vz0_2
      }
      else{
        y[1+6*(m-1)]=r_x[k]; //x0
        y[2+6*(m-1)]=v_x[k]; //vx_0
        y[3+6*(m-1)]=r_y[k]; //y0
        y[4+6*(m-1)]=v_y[k]; //vy_0
        y[5+6*(m-1)]=r_z[k]; //z0
        y[6+6*(m-1)]=v_z[k]; //vz_0
      }
    }
    fprintf(fpt_rk4_soft,"%g,", t);
      for(int m=1; m<=N; m++){
        if (m==N){
          fprintf(fpt_rk4_soft,"%g, %g, %g, %g, %g, %g", r_x[m-1], r_y[m-1], r_z[m-1], v_x[m-1], v_y[m-1], v_z[m-1]);
          
        }
        else{
          fprintf(fpt_rk4_soft,"%g, %g, %g, %g, %g, %g, ", r_x[m-1], r_y[m-1], r_z[m-1], v_x[m-1], v_y[m-1], v_z[m-1]);
        }
      }
      fprintf(fpt_rk4_soft,"\n");
      for(int j=1; j<=nsteps[k]; ++j){
        deriv(t,y,dydx);
        rk4(y, dydx, n_eqs, t, h[k], y, *deriv);
        t=j*h[k];
        fprintf(fpt_rk4_soft,"%g, ", t);
        for(int m=1; m<=N; m++){
          if (m==N){
            fprintf(fpt_rk4_soft,"%g, %g, %g, %g, %g, %g", y[1+6*(m-1)], y[3+6*(m-1)], y[5+6*(m-1)], y[2+6*(m-1)], y[4+6*(m-1)], y[6+6*(m-1)]); 
          }
          else
            fprintf(fpt_rk4_soft,"%g, %g, %g, %g, %g, %g, ", y[1+6*(m-1)], y[3+6*(m-1)], y[5+6*(m-1)], y[2+6*(m-1)], y[4+6*(m-1)], y[6+6*(m-1)]);
        }
        fprintf(fpt_rk4_soft,"\n");
      }
      fprintf(fpt_rk4_soft,"\n\n");
    }
  free_vector(y,1,12);
	free_vector(dydx,1,12);
  fclose(fpt_rk4_soft);

  //Leapfrog Solution
  fpt_leap_soft=fopen("data_leap_soft.csv", "w+");
  for(int k=0; k<=1; k++){
    t=0.0;
    //nsteps = (int)t_max/h[k];
    printf("Orbital Period %d: %g \n",k+1,P[k]);
    printf("  nsteps = %d \n\n", nsteps[k]);

    for(int m=1; m<=N; m++){
      if(m % 2 == 0){
        y[1+6*(m-1)]=r_x2[k]; //x0_2
        y[2+6*(m-1)]=v_x2[k]; //vx0_2
        y[3+6*(m-1)]=r_y2[k]; //y0_2
        y[4+6*(m-1)]=v_y2[k]; //vy0_2
        y[5+6*(m-1)]=r_z2[k]; //z0_2
        y[6+6*(m-1)]=v_z2[k]; //vz0_2
      }
      else{
        y[1+6*(m-1)]=r_x[k]; //x0
        y[2+6*(m-1)]=v_x[k]; //vx_0
        y[3+6*(m-1)]=r_y[k]; //y0
        y[4+6*(m-1)]=v_y[k]; //vy_0
        y[5+6*(m-1)]=r_z[k]; //z0
        y[6+6*(m-1)]=v_z[k]; //vz_0
      }
    }
    fprintf(fpt_leap_soft,"%g,", t);
      for(int m=1; m<=N; m++){
        if (m==N){
          fprintf(fpt_leap_soft,"%g, %g, %g, %g, %g, %g", r_x[m-1], r_y[m-1], r_z[m-1], v_x[m-1], v_y[m-1], v_z[m-1]);
          
        }
        else{
          fprintf(fpt_leap_soft,"%g, %g, %g, %g, %g, %g, ", r_x[m-1], r_y[m-1], r_z[m-1], v_x[m-1], v_y[m-1], v_z[m-1]);
        }
      }
      fprintf(fpt_leap_soft,"\n");
      for(int j=1; j<=nsteps[k]; ++j){
        deriv(t,y,dydx);
        leapfrog(y, dydx, n_eqs, t, h[k], y, *deriv);
        t=j*h[k];
        fprintf(fpt_leap_soft,"%g, ", t);
        for(int m=1; m<=N; m++){
          if (m==N){
            fprintf(fpt_leap_soft,"%g, %g, %g, %g, %g, %g", y[1+6*(m-1)], y[3+6*(m-1)], y[5+6*(m-1)], y[2+6*(m-1)], y[4+6*(m-1)], y[6+6*(m-1)]); 
          }
          else
            fprintf(fpt_leap_soft,"%g, %g, %g, %g, %g, %g, ", y[1+6*(m-1)], y[3+6*(m-1)], y[5+6*(m-1)], y[2+6*(m-1)], y[4+6*(m-1)], y[6+6*(m-1)]);
        }
        fprintf(fpt_leap_soft,"\n");
      }
      fprintf(fpt_leap_soft,"\n\n");
    }
  free_vector(y,1,12);
	free_vector(dydx,1,12);
  fclose(fpt_leap_soft);


  // freeing memory
  for(size_t i = 0; i < rows; ++i){
    free(r[i]);
  }
  free(r);

  return 0;
}