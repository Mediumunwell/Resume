import numpy as np
import matplotlib
from matplotlib import animation
from matplotlib.colors import BASE_COLORS as palette
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d.axes3d as axes3d
import pandas as pd
from cycler import cycler
from functools import partial

###########################################################
##    3D Static and Animated Plots of N-Body Problem     ##
###########################################################

##    Parameters that need to match defined variables in N_Body...c
N=400 #Set to N
t_max=300 #Set to N_STEPS
Animation_xyz_limits = 20 #Set to R_AVG
Spread = 5 #Set to SPREAD


#AU_per_pc=206265
newlimit1 = (-1.5*Animation_xyz_limits-3*Spread)
newlimit2 = (1.5*Animation_xyz_limits+3*Spread)
#####################################################
##    Plot 3D Static PNG Of Orbital Trajectories   ##
#####################################################

##    Color Scheme from colormap gradient
#n=9
#color = plt.cm.cubehelix(np.linspace(0.1, 0.6,n))
#color = plt.cm.twilight(np.linspace(0.1, 0.6,n))
#color = plt.cm.twilight_shifted(np.linspace(0.1, 0.6,n))
#color = plt.cm.inferno(np.linspace(0.1, 0.6,n))
#color = plt.cm.plasma(np.linspace(0.1, 0.7,n))
#color = plt.cm.gist_ncar(np.linspace(0.1, 0.6,n))
#matplotlib.rcParams['axes.prop_cycle'] = cycler('color', color)

##   Set Custom Color Scheme
color = (cycler(color=['#1d3b5a','#ffc131','#ffce4e', '#ffe263','#ffd953','#445f7f','#b9d7dc','#db6b90','#aa3347','#d8c7d4','#b97125','#f25576',
            '#447e9e', '#b14c5b', '#8eadc8', '#7b627c', '#98a38d']))
matplotlib.rcParams['axes.prop_cycle'] = cycler('color', color)

##   Plot 3D image
df=pd.read_csv('data_rk4_NBody.dat', sep=" ", header=None)
fig = plt.figure()
ax = plt.axes(projection = '3d')

#ax.set_prop_cycle(custom_cycler) #to set color scheme based on figure (google this line for other line needed)
for m in range(0, N):
    X_list = []
    Y_list = []
    Z_list = []
    t_list = []
    Y= []
    for t in range(0, t_max-1):
        #if m==1:
        X_list += [df.iloc[t,2+7*(m-1)]]
        Y_list += [df.iloc[t,4+7*(m-1)]]
        Z_list += [df.iloc[t,6+7*(m-1)]]
        t_list += [t]
        #if m==1 and t==0:
            #xb = X_list[0] # need to define xb=0, yb=0, zb=0
            #yb = Y_list[0] # to check black hole starting position
            #zb = Z_list[0] # time starts at dt[1] so values slightly > 0
        if m==2 and t==0:
            x1 = X_list[0]
            y1 = Y_list[0]
            z1 = Z_list[0]
    Y = [X_list, Y_list, Z_list]



    ax.scatter(Y[0][-1], Y[1][-1], Y[2][-1], marker = "o", s = 75, label = "mass " + str(m+1))
    ax.plot3D(Y[0][:], Y[1][:], Y[2][:], label = "tail " + str(m+1))

#print("Check Initial Conditions for Black Hole:  pos = <",xb,", ",yb,", ",zb," >")
print("\nCheck data for mass 1, t = 1:  pos = <",x1,",",y1,",",z1,">")

##   Set Static Figure "N_Body.png" Settings
#ax.set_xlim3d(-4, 4)
#ax.set_ylim3d(-4, 4)
#ax.set_zlim3d(-4, 4)
'''
ax.set_xlabel("x (pc)")
ax.set_ylabel("y (pc)")
ax.set_zlabel("z (pc)")
ax.xaxis.pane.set_edgecolor('purple')
ax.yaxis.pane.set_edgecolor('purple')
ax.zaxis.pane.set_edgecolor('purple')
ax.grid(color='p', linestyle='-', linewidth=2, alpha=0.5)
fig.patch.set_facecolor('black')
plt.axis('On')
fig.set_facecolor('black')
ax.set_facecolor('black') 
ax.grid(True) 
ax.xaxis.pane.fill = False
ax.yaxis.pane.fill = False
ax.zaxis.pane.fill = False
'''
plt.savefig("N_Body.png")

##############################
##    Plot 3D animation     ##
##############################

##   Set Static Figure "N_Body.png" Settings
fig = plt.figure(figsize=(6,6))
ax = plt.axes(projection = '3d')
ax.set_xlim3d(newlimit1, newlimit2)
ax.set_ylim3d(newlimit1, newlimit2)
ax.set_zlim3d(newlimit1, newlimit2)
ax.set_xlabel("x (pc)")
ax.set_ylabel("y (pc)")
ax.set_zlabel("z (pc)")
ax.xaxis.pane.set_edgecolor('purple')
ax.yaxis.pane.set_edgecolor('purple')
ax.zaxis.pane.set_edgecolor('purple')
ax.grid(color='p', linestyle='-', linewidth=2, alpha=0.5)
fig.patch.set_facecolor('black')
plt.axis('On')
fig.set_facecolor('black')
ax.set_facecolor('black') 
ax.grid(True) 
ax.xaxis.pane.fill = False
ax.yaxis.pane.fill = False
ax.zaxis.pane.fill = False

trail = [10]*20

Y_full = []

def Animate3D(k):
    #if k > 20:
        #if k % 20 == 0:
            #ax.view_init(elev=2*np.pi*np.cos(k), azim=2*np.pi*np.sin(k))
            #ax.view_init(elev=180*np.pi*np.cos(k)/(2*np.pi), azim=k/20)
    for i , ligne in enumerate(lignes, 0):
        ligne.set_data(Y_full[3*i][k:max(1, k - trail[0]):-1], Y_full[1+3*i][k:max(1, k - trail[0]):-1])
        ligne.set_3d_properties(Y_full[2+3*i][k:max(1, k - trail[0]):-1])
        
    return lignes

'''
def update_artists(frames, artists, lambdas):
    """Update artists with data from each frame."""
    flux, day = frames

    artists.flux_line.set_data(lambdas, flux)
    artists.day.set_text(day)
'''

Y_full = []

for m in range(0, N):
    X_list = []
    Y_list = []
    Z_list = []
    t_list = []
    Y = []
    for t in range(1, t_max):
        X_list += [df.iloc[t,2+7*(m)]]
        Y_list += [df.iloc[t,4+7*(m)]]
        Z_list += [df.iloc[t,6+7*(m)]]
        t_list += [t]

    #XX=np.vstack(X_list)
    #YY=np.vstack(Y_list)
    #ZZ=np.vstack(Z_list)
    Y = [X_list, Y_list, Z_list]
    Y_full += Y


lignes = [ax.plot([], [], "o-", markevery = 20)[0] for _ in range(N)]


#anim3D = animation.FuncAnimation(fig, Animate3D, frames = t_max//5 , interval = 5, blit = False)

# 3. Apply the three plotting functions written above
#init = partial(init_fig, fig=fig, ax=ax, artists=lignes)
#step = partial(frame_iter, from_day=-15, until_day=25)
#update = partial(update_artists, artists=artists,
                 #lambdas=np.arange(3298, 9700, 2.5))

# 4. Generate the animation
anim3D = animation.FuncAnimation(
    fig=fig,
    func=Animate3D,
    frames=t_max//5,
    save_count=t_max,
    repeat_delay=5000,
)

#f = r"c://Users/xx/Desktop/animation.gif" 
writergif = animation.PillowWriter(fps=10)
anim3D.save("N_Body_Animation.gif", writer=writergif, dpi=150)

#writervideo = animation.FFMpegWriter(fps=60) 
#anim3D.save('N_Body.mov'writer=writervideo)
#anim3D.save('N_Body.avi'writer=writervideo)
