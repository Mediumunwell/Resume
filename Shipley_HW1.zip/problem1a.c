#include <stdio.h>
#include <time.h>
#include <math.h>

FILE *fpt;

/* #define GNUPLOT "gnuplot -persist" */

double getCPU(void)
{
	return (double) clock()/CLOCKS_PER_SEC; /* convert to sec */
}

void Time(int n, int i) {
  int k;
  double p; 
      if (i==0) 
        for (k = 0; k < n; ++k) {
            if (k == 0)
              p = 0.0;
            else
              p = p + 5.0;
        }
      else if (i=1)
        for (k = 0; k < n; ++k) {
            if (k == 0)
              p = 1.0;
            else
              p = p * 1.000001;
        }
      else if (i=2)
        for (k = 0; k < n; ++k) {
            if (k == 0)
              p = 1.1;
            else
              p = sqrt(p);
        }
      else if (i=3)
        for (k = 0; k < n; ++k) {
            if (k == 0)
              p = 1.1;
            else
              p = pow(p,0.5);
        }
}

int main() 
  {
    /* fpt = fopen("data1a.csv", "w+"); This file is being made to store the values for the first table */
    fpt = fopen("data1c.csv", "w+"); /*This file stores the values and is moved to data1a.csv for part a's plot then is rewritten for part c*/
    fprintf(fpt,"n, dt\n");
    long int n[7] = {1e6,3e6, 1e7, 3e7, 1e8, 300000000, 1000000000};
    double p[4][7], data1[7], data2[7], data3[7], data4[7];
    int i,j,k;
    printf("\n========================================================================================");
    printf("\n|      n       |     Value Counted    |     Operation     |    CPU time   |   MFFLOPs  |");
    printf("\n========================================================================================");
    double t0, sum, mavg;
    double dt[4][7], m[4][7];
    char *str[4] = {"+", "x", "sqrt", "^"};
    for (int i = 0; i < 4; ++i) {
      for (int j = 0; j < 7; ++j) {
	      t0 = getCPU();   /* get init value */
	      Time(n[j],k);
	      dt[i][j] = getCPU() - t0;
        p[0][j]=n[j]*5.0;
        p[1][j]=pow(1.000001,n[j]);
        p[2][j]=1.0;
        p[3][j]=1.0;
        m[i][j]=n[j]/dt[i][j];
        sum += m[i][j];
        if (i==1 && j==6){
          printf("\n|     %0.0e \t\t%0.1e \t\t\t%c \t       %f      %3.2e  |", n[j]*1.0, p[i][j], *str[i], dt[i][j], m[i][j]);
        }
        else{
          printf("\n|     %0.0e \t\t%0.1e \t     %4c \t       %7f      %3.2e  |", n[j]*1.0, p[i][j], *str[i], dt[i][j], m[i][j]);
        }
        if  (j==6 && i==0 || j==6 && i==1 || j==6 && i==2){
          printf("\n========================================================================================");
        }
        fprintf(fpt,"%ld, %f\n",n[j],dt[i][j]);
      }  
    }
    printf("\n========================================================================================\n\n");
    mavg=sum/28;
    printf("MFLOPS average = %0.2e\n\n",mavg);
    fclose(fpt);
    return 0;

  }