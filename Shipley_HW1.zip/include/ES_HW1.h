/*
include files/functions
*/
#ifndef ES_HW1
#define ES_HW1

void Time(int, int);
void MyFunc1(int, int);

#endif