The code compiles, runs all the files, and plots all the plots using the Makefile

Type make in the linux command line to:
   compile problem1.c (Creates table already on the HW questions before problem 1a filled in with the added column CPU times)
   compile problem1a.c with cc and runs it again compiling with -gcc -O1 (Creates a table for each as described in 1a and 1c)
   run the resulting executable files named 1 1a and 1c
   create a .csv data file for 1a and 1c with the first column being iterations and second being delta CPU time 
   Plot plot1b.plt and plot1c.plt using gnuplot (I played around with their file extension. It was .gnu at one time. Not a factor)

Type make clean to remove all created files after running make