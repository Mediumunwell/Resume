#include <stdio.h>
#include <time.h>
#include <math.h>

/*  #define INITVALUE 10.0   */

void MyFunc1(int n, int k)
{
int i,x;
double y;
if (k==0){
    x=0;
    for (i=0;i<n;++i){
    x=x+5;
    }}
if (k==1){
    for (i=0;i<n;++i){
    x=0;
    x=x-5;
    }}
if (k==2){
    x=1;
    for (i=0;i<n;++i){
    x=x*1;
    }}
if (k==3){
    for (i=0;i<n;++i){
    x=1;
    x=x/1;
    }}
if (k==4){
    for (i=0;i<n;++i){
    y=0.0;
    y=y+5.0;
    }}
if (k==5){
    for (i=0;i<n;++i){
    y=0.0;
    y=y-5.0;
    }}
if (k==6){
    for (i=0;i<n;++i){
    y=1.0;
    y=y*1.0;
    }}
if (k==7){
    for (i=0;i<n;++i){
    y=1.0;
    y=y/1.0;
    }}
if (k==8){
    for (i=0;i<n;++i){
    y=1.1;
    y=sqrt(y);
    }}
if (k==9){
    for (i=0;i<n;++i){
    y=1.1;
    y=pow(y,0.5);
    }}
}

double getCPU(void)
{
	return (double) clock()/CLOCKS_PER_SEC; /* convert to sec */
}
int main(void)
{
    int k;
    double t0,dt[10]={0,0,0,0,0,0,0,0,0,0};
    for (k=0;k<10;++k){
	    int n=100000;
	    t0 = getCPU();   /* get init value */
	    MyFunc1(n,k);
	    dt[k] = getCPU() - t0;    /*diff to get exec time */
	    /*(void) printf("Execution time: %g sec\n",dt[k]);*/
    }


printf("\n===================================================================================");
printf("\n  Operand Type       Starting Value            Operation               CPU time");
printf("\n===================================================================================");
printf("\n     integer               0                     add 5                 %g",dt[0]);
printf("\n     integer               0                   subtract 5              %g",dt[1]);
printf("\n     integer               1                 multiply by 1             %g",dt[2]);
printf("\n     integer               1                  divide by 1              %g",dt[3]);
printf("\n  double-precision        0.0                   add 5.0                %g",dt[4]);
printf("\n  double-precision        0.0                 subtract 5.0             %g",dt[5]);
printf("\n  double-precision        1.0             multiply by 1.000001         %g",dt[6]);
printf("\n  double-precision        1.0              divide by 1.000001          %g",dt[7]);
printf("\n  double-precision        1.1            take the root (sqrt(x))       %g",dt[8]);
printf("\n  double-precision        1.1           raise to 0.5 (pow(x,0.5))      %g\n\n",dt[9]);
}