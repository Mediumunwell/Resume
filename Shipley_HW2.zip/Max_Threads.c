#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdbool.h>

#define MAX_THREAD_NUM 11000
void * threadTest(void* arg){
        while(true){
                sleep(5);
        }
        pthread_exit(NULL);
}

int main(){
        for(int i = 0;i< MAX_THREAD_NUM;i++){
                pthread_t tid;
                printf("create thread %d\n", i);
                int ret = pthread_create(&tid,NULL,&threadTest,NULL);
                if(ret != 0){
                        perror("pthread_create error");
                }
                pthread_detach(tid);
        }
        while(true){
                sleep(5);
        }
        return 0;

}