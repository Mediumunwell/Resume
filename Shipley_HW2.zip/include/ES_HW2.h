/*
include files/functions
*/
#ifndef ES_HW2
#define ES_HW2

void Time(int, int);
void TimeDyn(int, int);

#endif