The code compiles, runs all the homework files, and plots all the plots using the Makefile

   Find_Mem_Hogs is a csh script that will show how much memory files are using regardless of their directory (I think)
   Max_Threads.c when compiled and run will continue to use a thread and print the latest thread until the max is reached (I think)

Type make in the linux command line to:
   compile problem1a.c and problem2.c with cc -lm -g 
   run the resulting executable files named 1a 1b 1c with their two possible arguments: 1  or 2  # with comment description beside it = which HW question
      argument 1 = Program runs buidling Static Matrix
      argument 2 = Program runs buidling Dynamic Matrix
   create a .csv data files for plotting comparing 1a and 1c (Static, ij vs ji for both -O0 vs -O2) as well as 1b and 1c (Dynamic -O0 vs -O2)
   Plot All_Static.plt, Both_Dynamic.plt, and Compare_Fastest.plt using gnuplot
   run executable for problem 2

Type make clean to remove all created files after running make