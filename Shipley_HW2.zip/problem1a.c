#include <stdio.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/resource.h>
#include <pthread.h>
#include <string.h>


FILE *fpt;

/* #define GNUPLOT "gnuplot -persist" */
/* fpt = fopen("data1a.csv", "w+"); This file is being made in the make file using "cp" to store the values for the first table */

double getCPU(void)
{
	return (double) clock()/CLOCKS_PER_SEC; /* convert to sec */
}

void Time(int n, int i) {
  int j=1, k, m;
  float A[n][n];
  double dt[n][n], d_t[sizeof(A)], mflops[n][n], sum[2]; 
  double t0, mflop_avg[2];
  t0 = getCPU();   /* get init value */
  if (i==0){
    fpt = fopen("static_data1c_ij.csv", "w+"); /*This file stores the values and is moved to static_data1a_ij.csv for part a's plot then is rewritten for part c*/
    fprintf(fpt,"Iteration,        Row, Column,         dt,        flops\n");
    for (k = 0; k < n; ++k) {
      for (m = 0; m < n; ++m){
        A[k][m] += 5.0;
        dt[k][m] = getCPU() - t0;
        mflops[k][m]=j/(dt[k][m])/1e6;
        sum[i] += mflops[k][m];
        ++j;
        if (m >= n-5 && m < n && k >= n-1 && k < n){
          printf("\n|    %d    %d\t\tj in i \t\t    %f\t       %3.2e  |", k+1, m+1, dt[k][m], mflops[k][m]);
        }
        fprintf(fpt,"   %d,    %12d, %d,    %12g,    %12g\n", j, k, m, dt[k][m], mflops[k][m]);
      }
    }
  fclose(fpt);
  mflop_avg[i]=sum[i]/(n*n);
  }
  else if (i==1){
    fpt = fopen("static_data1c_ji.csv", "w+"); /*This file stores the values and is moved to static_data1a_ji.csv for part a's plot then is rewritten for part c*/
    fprintf(fpt,"Iteration,        Row, Column,         dt,        flops\n");
    for (m = 0; m < n; ++m) {
      for (k = 0; k < n; ++k) {
        A[k][m] += 5.0;
        dt[k][m] = getCPU() - t0;
        mflops[k][m]=j/(dt[k][m])/1e6;
        sum[i] += mflops[k][m];
        ++j;
        if (k >= n-1 && k < n && m >= n-5 && m < n){
          printf("\n|    %d    %d\t\ti in j \t\t    %f\t       %3.2e  |", k+1, m+1, dt[k][m], mflops[k][m]);
        }
        fprintf(fpt,"   %d,    %12d, %d,    %12g,    %12g\n", j, k, m, dt[k][m], mflops[k][m]);
      }
    }
  fclose(fpt);
  mflop_avg[i]=sum[i]/(n*n);
  }
  printf("\n==========================================================================\n");
  printf("|   MFLOPS avg:    %3.2e                                              |", mflop_avg[i]);
  printf("\n==========================================================================\n");
}

void TimeDyn(int n, int i) {
  int j=1, k, m;
  float **A;
  double dt[n][n], d_t[n*n], mflops[n][n], sum[2]; 
  float t0, mflop_avg;
  t0 = getCPU();   /* get init value */
  fpt = fopen("dynamic_data1c.csv", "w+"); /*This file stores the values and is moved to dynamic_data1b.csv for part b's plot then is rewritten for part c*/
  fprintf(fpt,"Iteration,        Row, Column,         dt,        flops\n");
  /*if (i==0) {  */
    A = (float **) malloc(m*sizeof(float *));
    assert(A);
    for (k = 0; k < n; ++k) {
      A[k] = (float *) malloc(n*sizeof(float));
      assert(A[k]);
    }
    for (k = 0; k < n; ++k) {
      for (m = 0; m < n; ++m){
        A[k][m] += 5.0;
        dt[k][m] = getCPU() - t0;
        /* if (j !=1){
          mflops[k][m]=j/(d_t[j]-d_t[j-1]);
        }
        else{
          mflops[k][m]=j/d_t[j];
        } */
        mflops[k][m] = j/dt[k][m]/1e6;
        ++j;
        sum[i] += mflops[k][m];
        if (m >= n-5 && m < n && k >= n-1 && k < n){
          printf("\n|   %d   %d\t       %f \t  %3.2e  |", k+1, m+1, dt[k][m], mflops[k][m]);
        }
        fprintf(fpt,"   %d,    %12d, %d,    %12g,    %12g\n", j, k, m, dt[k][m], mflops[k][m]);
      }
    }
    for (k = 0; k < n; k++){
      free((void *) A[k]);
    }
    free((void *) A);
  /*}
  else if (i=1) { 
    A = (float **) malloc(m*sizeof(float *));
    assert(A);
    for (k=0; k < n; k++) {
      A[k] = (float *) malloc(n*sizeof(float));
      assert(A[k]);
    }
    for (k = 0; k < n; ++k) {
        for (m = 0; m < n; ++m){
          A[k][m] = 5.0;
          dt[k][m] = getCPU() - t0;
          mflops[k][m]=k*m/dt[k][m];
          sum[i] += mflops[k][m];
          if (m >= n-4 && m < n && k >= n-4 && k < n){
            printf("\n|    %d \t\t ij \t\t   %f    \t      %3.2e   |", m, dt[k][m], mflops[k][m]);
          }
          fprintf(fpt,"%d, %f\n", n, dt[k][n]);
        }
      }
    for (k = 0; k < n; k++){
      free((void *) A[k]);
    }
    free((void *) A);
  } */
  fclose(fpt);
  mflop_avg=sum[i]/(n*n);
  printf("\n=====================================================\n");
  printf("|   MFLOPS avg:    %3.2e                         |", mflop_avg);
  printf("\n=====================================================\n");
}

int main(int argc,char *argv[]) {
  double data1, data2;
  int i, j;
  long int N;
    if (argc <= 1 ) {
      printf("Usage Error: %s takes argument(int n = 1 (Static Array) || 2 (Dynamic Array))\n",argv[0]);
      return 1;
    } 
  j = atoi(argv[1]); /* convert strings to integers */

  if (atoi(argv[1]) == 1){
    N= 50; /* Size of Static Matrix for both index/loop orders and -O0 and -02 optimizations */
  }
  if (atoi(argv[1]) == 2){
    N= 200; /* Size of Dynamic Matrix for both -O0 and -02 optimizations */
  }
  for (int i = 0; i < 2; ++i) {
    if (atoi(argv[1]) == 1){
      printf("\nSTATIC MATRIX");
      printf("\n==========================================================================");
      printf("\n|   row   col   |     Loop Order     |      CPU time     |     MFLOPS    |");
      printf("\n==========================================================================");
      Time(N,i);
    }
  }
  if (atoi(argv[1]) == 2){
    printf("\nDYNAMIC MATRIX");
    printf("\n=====================================================");
    printf("\n|   row   col   |      CPU time     |     MFLOPS    |");
    printf("\n=====================================================");
    TimeDyn(N,i);
  }
  return 0;
}

/* Unused code that did not work to print current stack size or threads used in Ubuntu WSL2 likely because I am using virtual memory

// for takes the size of threads stack
size_t stksize;
  
// attribute declaration
pthread_attr_t atr;

// it gets the threads stack size and give 
// value in stksize variable
pthread_attr_getstacksize(&atr, &stksize);
  
// print the current threads stack size
printf("Current stack size - > %ld\n", stksize);

struct rlimit rlim_stack;


pthread_attr_getstacksize(&atr, &stksize);
getrlimit (RLIMIT_STACK, &rlim_stack);
if (atoi(argv[1]) == 1 && n >= 1445 && n < 1448 || atoi(argv[1]) == 2 && n >= 1998 && n <= 2000 ){
  printf("Iteration: %d \t Current stack size: %ld\n", n, stksize);
  fprintf(stderr, "\t\t     Stack Limit Available = %ld and %ld max\n", rlim_stack.rlim_cur, rlim_stack.rlim_max); */