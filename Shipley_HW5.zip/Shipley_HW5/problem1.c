#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "nrutil.h"
#include "nr.h"

FILE *fpt_eul;
FILE *fpt_rk4;
FILE *fpt_leap;

void deriv(float t, float y[], float dydx[]){
  dydx[1]=y[2];
  dydx[2]=-y[1];
}

void leapfrog(float y[], float dydx[], int n, float x, float h, float yout[],
	void (*derivs)(float, float [], float []))
{
  float xh=x+h/2;
  for (int i=1;i<=n;i=i+2){
    y[i+1] = y[i+1]+h/2*dydx[i+1];
  }
  for (int i=1;i<=n;i=i+2){
    yout[i] = y[i] + h * y[i+1];
  }
  (*deriv)(xh,yout,dydx);
  for (int i=1;i<=n;i=i+2){
    yout[i+1]=y[i+1]+h/2*dydx[i+1];
  }
}

void Euler(float y[], float dydx[], int n, float x, float h, float yout[]){
  for (int i=1;i<=n;i++){
    yout[i] = y[i] + h * dydx[i];
  }
}

int main(){
  double error;
  float x0=0, t_max=15, t;
  float h[5]={1,0.3,0.1,0.03,0.01};
  int nsteps, N=2;
  float *y=vector(1, N);
  float *dydx=vector(1, N);
  fpt_eul=fopen("data_eul.csv", "w+");

  for (int i=0; i<=5; ++i){
    if (i==1){
      nsteps = 50;
    }
    else{
      nsteps = (int)t_max/h[i];
    }
    t=0;
    y[1]=0;
    y[2]=1.0;
    for(int j=1; j<=nsteps; ++j){
    deriv(t, y, dydx);
    Euler(y, dydx, N, t, h[i], y);
    t=j*h[i];
    fprintf(fpt_eul,"%g, %g, %g \n", t, y[1], y[2]);
    }
  fprintf(fpt_eul,"\n\n");
  }
  fclose(fpt_eul);



  fpt_rk4=fopen("data_rk4.csv", "w+");
  for(int i=0; i<=5; i++){
    if (i==1){
      nsteps = 50;
    }
    else{
      nsteps = (int)t_max/h[i];
    }
    t=0;
    y[1]=0;
    y[2]=1.0;
    for(int j=1; j<=nsteps; ++j){
      deriv(t,y,dydx);
      rk4(y, dydx, N, t, h[i], y, *deriv);
      t=j*h[i];
      fprintf(fpt_rk4,"%g, %g, %g \n", t, y[1], y[2]);
    }
  fprintf(fpt_rk4,"\n\n");
  }
  fclose(fpt_rk4);


  fpt_leap=fopen("data_leap.csv", "w+");
  for(int i=0; i<=5; i++){
    if (i==1){
      nsteps = 50;
    }
    else{
      nsteps = (int)t_max/h[i];
    }
    t=0;
    y[1]=0;
    y[2]=1.0;
    for(int j=1; j<=nsteps; ++j){
      deriv(t,y,dydx);
      leapfrog(y, dydx, N, t, h[i], y, *deriv);
      t=j*h[i];
      fprintf(fpt_leap,"%g, %g, %g \n", t, y[1], y[2]);
    }
  fprintf(fpt_leap,"\n\n");
  }
  fclose(fpt_leap);


  //float x0 = 0, y2 = 1, x = 2, g = 0.2;
  //printf("\nThe value of x at t is : %f",  rk(x0, y2, x, g));
  return 0;
}

