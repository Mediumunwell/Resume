The code compiles, runs all the homework files, and plots the solutions using the Makefile

Type make in the linux command line to:
   compile problem1.c and problem2.c with cc nrutil.c rk4.c -lm -g 
   run the resulting executable files named 1 and 2
   Plot the Euler solution vs sin(x)
   Plot the Leapfrog and RK4 solutions vs sin(x)
   Plot the errors at t=15 for the different step sizes
   Plot the orbit for the particle using Leapfrog and RK4
   Plot the energy values over time according to Leapfrog and RK4

Type make clean to remove all created files after running make



files:
HW5.pdf     writeup of solutions with figures

Makefile    compiles and plots the following

problem1.c  solution to question (1) outputs to data files for each method

problem2.c  solution to question (2)    "     "   "    "    "    "    "

nrutil.c    Numerical Recipes in C

rk4.c       function for 4th order Runge-Kutta ODE solving method

*.plt       gnuplot files to plot graphs

include
 >ES_HW5.h  header for makefile (not included as there are no external functions I created, I wrote my functions before main())

nr.H        header for Numerical Recipes

make:
   *.csv    data files for plots
   *.png    plots
   *.tex    Latex file paired with .eps version to have plot with Latex
   *.eps       "   "     "      "  .tex    "     "   "    "    "     "
            uses command: \input{plot2_Orbits.tex}  in overleaf