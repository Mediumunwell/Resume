#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "nrutil.h"
#include "nr.h"

FILE *fpt2_rk4;
FILE *fpt2_leap;

void deriv(float t, float y[], float dydx[]){
  dydx[1]=y[2];
  dydx[2]=-2*y[1]/pow(1+2*y[1]*y[1]+2*y[3]*y[3],3/2);
  dydx[3]=y[4];
  dydx[4]=-2*y[3]/pow(1+2*y[1]*y[1]+2*y[3]*y[3],3/2);
}

void leapfrog(float y[], float dydx[], int n, float x, float h, float yout[],
	void (*derivs)(float, float [], float []))
{
  float xh=x+h/2;
  for (int i=1;i<=n;i=i+2){
    y[i+1] = y[i+1]+h/2*dydx[i+1];
  }
  for (int i=1;i<=n;i=i+2){
    yout[i] = y[i] + h * y[i+1];
  }
  (*deriv)(xh,yout,dydx);
  for (int i=1;i<=n;i=i+2){
    yout[i+1]=y[i+1]+h/2*dydx[i+1];
  }
}


int main(){
  float x0=1, y0=0, t_max=100, t;
  float h[5]={1,0.5,0.25,0.1};
  int nsteps, N=4;
  float *y=vector(1, N);
  float *dydx=vector(1, N);

  fpt2_rk4=fopen("data2_rk4.csv", "w+");
  for(int i=0; i<=4; i++){
    /*if (i==1){
      nsteps = 50;
    }
    else{
      nsteps = (int)t_max/h[i];
    }*/
    nsteps = (int)t_max/h[i];
    t=0;
    y[1]=x0;
    y[2]=0.0;
    y[3]=y0;
    y[4]=0.1;
    for(int j=1; j<=nsteps; ++j){
      deriv(t,y,dydx);
      rk4(y, dydx, N, t, h[i], y, *deriv);
      t=j*h[i];
      fprintf(fpt2_rk4,"%g, %g, %g, %g, %g \n", t, y[1], y[2], y[3], y[4]);
    }
  fprintf(fpt2_rk4,"\n\n");
  }
  fclose(fpt2_rk4);


  fpt2_leap=fopen("data2_leap.csv", "w+");
  for(int i=0; i<=4; i++){
    /* if (i==1){
      nsteps = 50;
    }
    else{
      nsteps = (int)t_max/h[i];
    }*/
    nsteps = (int)t_max/h[i];
    t=0;
    y[1]=x0;
    y[2]=0.0;
    y[3]=y0;
    y[4]=0.1;
    for(int j=1; j<=nsteps; ++j){
      deriv(t,y,dydx);
      leapfrog(y, dydx, N, t, h[i], y, *deriv);
      t=j*h[i];
      fprintf(fpt2_leap,"%g, %g, %g, %g, %g \n", t, y[1], y[2], y[3], y[4]);
    }
  fprintf(fpt2_leap,"\n\n");
  }
  fclose(fpt2_leap);


  //float x0 = 0, y2 = 1, x = 2, g = 0.2;
  //printf("\nThe value of x at t is : %f",  rk(x0, y2, x, g));
  return 0;
}

